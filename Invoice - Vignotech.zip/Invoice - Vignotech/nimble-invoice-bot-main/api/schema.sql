-- =====================================================
-- Invoice Management System - MariaDB Schema
-- Run this SQL in cPanel's phpMyAdmin to create tables
-- =====================================================

-- Clients Table
CREATE TABLE IF NOT EXISTS clients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    company_name VARCHAR(255),
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    address_line1 TEXT NOT NULL,
    address_line2 TEXT,
    city VARCHAR(100) NOT NULL,
    state_province VARCHAR(100),
    postal_code VARCHAR(20),
    country VARCHAR(100) NOT NULL,
    country_code VARCHAR(10),
    tax_id VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Templates Table (for reusable invoice templates)
CREATE TABLE IF NOT EXISTS templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    client_notes TEXT,
    terms TEXT,
    thank_you_message VARCHAR(500),
    signature_info JSON,
    company_info JSON,
    payment_info JSON,
    is_default TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_name (name),
    INDEX idx_default (is_default)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Invoices Table
CREATE TABLE IF NOT EXISTS invoices (
    id VARCHAR(50) PRIMARY KEY,
    invoice_number VARCHAR(50) NOT NULL UNIQUE,
    date VARCHAR(20) NOT NULL,
    due_date VARCHAR(20) NOT NULL,
    client JSON NOT NULL,
    company JSON NOT NULL,
    items JSON NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'USD',
    subtotal DECIMAL(15, 2) DEFAULT 0,
    tax_rate DECIMAL(5, 2) DEFAULT 0,
    tax_amount DECIMAL(15, 2) DEFAULT 0,
    discount_type VARCHAR(20) DEFAULT 'percentage',
    discount_value DECIMAL(15, 2) DEFAULT 0,
    discount_amount DECIMAL(15, 2) DEFAULT 0,
    total DECIMAL(15, 2) NOT NULL,
    notes TEXT,
    terms TEXT,
    payment_info JSON,
    invoice_notes JSON,
    signature JSON,
    status ENUM('draft', 'sent', 'paid', 'overdue') DEFAULT 'draft',
    client_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_invoice_number (invoice_number),
    INDEX idx_status (status),
    INDEX idx_date (date),
    INDEX idx_client_id (client_id),
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default template
INSERT INTO templates (name, client_notes, terms, thank_you_message, signature_info, is_default)
VALUES (
    'Default Template',
    'Dear Teo,

Thank you for choosing VignoTech Digital Solutions for Teo''s Bakery website!

📦 WHAT''S INCLUDED (3-YEAR PACKAGE):
• Domain (.com) - 3 years
• Premium Hosting - 3 years
• Custom Website Design & Development
• FREE: Production Support, SSL Certificate, Email Hosting, Backup Service, Content Writing, and Annual Maintenance (C$445 value!)

📄 WHAT WE NEED FROM YOU:
• Business logo (high resolution, PNG/SVG preferred)
• Photos of your bakery, products, and team
• Menu/product list with descriptions and prices
• Business hours and contact information
• Social media links (if any)
• Any specific colors, fonts, or design preferences
• About Us content (your story, vision, etc.)

⏰ TIMELINE:
• Website delivery: 10-14 business days after receiving all content
• Please provide content within 14 days to avoid delays

📧 SUPPORT:
• Email: vignotechdigital@gmail.com
• Hours: Mon-Fri, 10 AM - 6 PM IST
• Response time: Within 24 hours

🔄 RENEWAL (AFTER 3 YEARS):
• Domain renewal: ~C$25/year
• Hosting renewal: ~C$50/year
• Support/Maintenance: As per current rates
• Reminder will be sent 30 days before expiry

💳 PAYMENT:
• Total Amount: C$420.00
• Method: UPI - 7397236621@jupiteraxis
• Please share payment screenshot after transfer

We''re excited to build your bakery''s online presence!',
    'TERMS & CONDITIONS:

1. Payment due upon receipt via PayPal/Wise/Bank Transfer.

2. Domain & hosting valid for 3 years. Renewal charges apply thereafter.

3. Website delivery: 10-14 business days from content receipt.

4. Includes 3 revision rounds. Additional changes billed separately.

5. Complimentary services (C$445 value) included free for 3 years.

6. Full ownership transfers upon complete payment.

7. Non-refundable once work commences.

8. Governed by the laws of India.

9. Payment constitutes acceptance of these terms.',
    'We are grateful for your confidence in our services and look forward to serving you again.',
    '{"authorizedSignatory": "Harivignesh Jeeva", "designation": "Developer"}',
    1
);
