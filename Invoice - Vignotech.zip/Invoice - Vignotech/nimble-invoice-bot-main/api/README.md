# cPanel Deployment Guide

## 1. Build the React App

```bash
npm run build
```

This creates a `dist` folder with your production files.

## 2. Upload to cPanel

### Frontend (dist folder)
1. Log into cPanel
2. Open **File Manager**
3. Navigate to `public_html`
4. Upload all contents from `dist/` folder

### API (api folder)
1. Create an `api` folder inside `public_html`
2. Upload all PHP files from the `api/` folder:
   - `config.php`
   - `clients.php`
   - `invoices.php`
   - `templates.php`

## 3. Create MariaDB Database

1. In cPanel, go to **MySQL® Databases**
2. Create a new database (e.g., `yourusername_invoices`)
3. Create a database user with password
4. Add user to database with **ALL PRIVILEGES**

## 4. Run Database Schema

1. Open **phpMyAdmin** in cPanel
2. Select your new database
3. Click **Import** tab
4. Upload `api/schema.sql`
5. Click **Go** to run

## 5. Configure API

Edit `api/config.php` with your database credentials:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'yourusername_invoices');
define('DB_USER', 'yourusername_dbuser');
define('DB_PASS', 'your_secure_password');
```

## 6. Add .htaccess for React Router

Create `.htaccess` in `public_html`:

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  
  # Don't rewrite API requests
  RewriteRule ^api/ - [L]
  
  # Don't rewrite files or directories
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  
  # Rewrite everything else to index.html
  RewriteRule . /index.html [L]
</IfModule>
```

## 7. Set CORS (Production)

Edit `api/config.php` line 8:

```php
// Change from:
header("Access-Control-Allow-Origin: *");

// To your domain:
header("Access-Control-Allow-Origin: https://yourdomain.com");
```

## 8. Test

Visit your domain and test:
- Creating invoices
- Viewing invoices
- Deleting invoices

## Troubleshooting

### API returns 500 error
- Check PHP error logs in cPanel
- Verify database credentials in `config.php`

### CORS errors
- Ensure `Access-Control-Allow-Origin` header is set correctly

### React routes show 404
- Verify `.htaccess` file exists and contains rewrite rules
- Check if `mod_rewrite` is enabled

## Environment Variable (Optional)

For local development pointing to production API, create `.env`:

```
VITE_API_URL=https://yourdomain.com/api
```
