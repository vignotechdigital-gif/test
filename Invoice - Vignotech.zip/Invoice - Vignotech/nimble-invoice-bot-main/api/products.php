<?php
/**
 * Products API Endpoints
 * GET    /api/products.php         - Get all products
 * GET    /api/products.php?id=X    - Get single product
 * POST   /api/products.php         - Create product
 * PUT    /api/products.php?id=X    - Update product
 * DELETE /api/products.php?id=X    - Delete product
 */

require_once 'config.php';

$db = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? sanitizeString($_GET['id'], 50) : null;

switch ($method) {
    case 'GET':
        if ($id) {
            getProduct($db, $id);
        } else {
            getAllProducts($db);
        }
        break;
    case 'POST':
        createProduct($db);
        break;
    case 'PUT':
        if ($id) {
            updateProduct($db, $id);
        } else {
            jsonResponse(['error' => 'Product ID required'], 400);
        }
        break;
    case 'DELETE':
        if ($id) {
            deleteProduct($db, $id);
        } else {
            jsonResponse(['error' => 'Product ID required'], 400);
        }
        break;
    default:
        jsonResponse(['error' => 'Method not allowed'], 405);
}

function getAllProducts($db) {
    $stmt = $db->query("SELECT * FROM products ORDER BY sort_order ASC, title ASC");
    $products = $stmt->fetchAll();
    jsonResponse($products);
}

function getProduct($db, $id) {
    $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    
    if ($product) {
        jsonResponse($product);
    } else {
        jsonResponse(['error' => 'Product not found'], 404);
    }
}

function createProduct($db) {
    $data = getJsonInput();
    
    $required = ['id', 'title'];
    $missing = validateRequired($data, $required);
    if (!empty($missing)) {
        jsonResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
    }
    
    $stmt = $db->prepare("
        INSERT INTO products (id, title, description, default_rate, default_quantity, sort_order)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        sanitizeString($data['id'], 50),
        sanitizeString($data['title'], 255),
        sanitizeString($data['description'] ?? '', 2000),
        floatval($data['default_rate'] ?? 0),
        intval($data['default_quantity'] ?? 1),
        intval($data['sort_order'] ?? 0)
    ]);
    
    $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$data['id']]);
    $product = $stmt->fetch();
    
    jsonResponse($product, 201);
}

function updateProduct($db, $id) {
    $data = getJsonInput();
    
    $stmt = $db->prepare("SELECT id FROM products WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        jsonResponse(['error' => 'Product not found'], 404);
    }
    
    $fields = [];
    $values = [];
    
    $stringFields = ['title' => 255, 'description' => 2000];
    $numericFields = ['default_rate', 'default_quantity', 'sort_order'];
    
    foreach ($stringFields as $field => $maxLen) {
        if (isset($data[$field])) {
            $fields[] = "$field = ?";
            $values[] = sanitizeString($data[$field], $maxLen);
        }
    }
    
    foreach ($numericFields as $field) {
        if (isset($data[$field])) {
            $fields[] = "$field = ?";
            $values[] = floatval($data[$field]);
        }
    }
    
    if (empty($fields)) {
        jsonResponse(['error' => 'No fields to update'], 400);
    }
    
    $values[] = $id;
    $sql = "UPDATE products SET " . implode(', ', $fields) . " WHERE id = ?";
    $stmt = $db->prepare($sql);
    $stmt->execute($values);
    
    $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    
    jsonResponse($product);
}

function deleteProduct($db, $id) {
    $stmt = $db->prepare("SELECT id FROM products WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        jsonResponse(['error' => 'Product not found'], 404);
    }
    
    $stmt = $db->prepare("DELETE FROM products WHERE id = ?");
    $stmt->execute([$id]);
    
    jsonResponse(['message' => 'Product deleted successfully']);
}
?>
