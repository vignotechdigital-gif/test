<?php
/**
 * Database Configuration for MariaDB
 * Update these values with your cPanel database credentials
 */

// CORS Headers - Allow requests from your frontend domain
$allowed_origins = [
    'http://localhost:5173',
    'http://localhost:3000',
    'http://localhost:8080',
    'https://vignotech.netlify.app',
    'https://invoice.vignotech.in',
    'https://nimble-invoice-bot.lovable.app',
];

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';

// Check if origin is in allowed list OR is a Lovable preview/project domain
$is_allowed = in_array($origin, $allowed_origins) || 
              strpos($origin, '.lovable.app') !== false || 
              strpos($origin, '.lovableproject.com') !== false;

if ($is_allowed && $origin !== '') {
    header("Access-Control-Allow-Origin: $origin");
} else {
    header("Access-Control-Allow-Origin: *");
}
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json; charset=UTF-8");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database Configuration - UPDATE THESE VALUES
define('DB_HOST', 'sdb-n.hosting.stackcp.net');
define('DB_NAME', 'invoice-3139366e98');  // e.g., 'yourusername_invoices'
define('DB_USER', 'admin-b434');  // e.g., 'yourusername_dbuser'
define('DB_PASS', 'Dallas99!.0');
define('DB_CHARSET', 'utf8mb4');

/**
 * Get database connection
 * @return PDO|null
 */
function getDBConnection() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];
        return new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]);
        exit();
    }
}

/**
 * Send JSON response
 * @param mixed $data
 * @param int $statusCode
 */
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode($data);
    exit();
}

/**
 * Get JSON input from request body
 * @return array
 */
function getJsonInput() {
    $input = file_get_contents('php://input');
    return json_decode($input, true) ?? [];
}

/**
 * Validate required fields
 * @param array $data
 * @param array $required
 * @return array Missing fields
 */
function validateRequired($data, $required) {
    $missing = [];
    foreach ($required as $field) {
        if (!isset($data[$field]) || (is_string($data[$field]) && trim($data[$field]) === '')) {
            $missing[] = $field;
        }
    }
    return $missing;
}

/**
 * Sanitize string input
 * @param string $input
 * @param int $maxLength
 * @return string
 */
function sanitizeString($input, $maxLength = 255) {
    if (!is_string($input)) return '';
    $input = trim($input);
    $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    return mb_substr($input, 0, $maxLength);
}

/**
 * Sanitize email
 * @param string $email
 * @return string|false
 */
function sanitizeEmail($email) {
    $email = filter_var(trim($email), FILTER_SANITIZE_EMAIL);
    return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : false;
}
?>
