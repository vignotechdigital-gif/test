<?php
/**
 * Client Services API Endpoints
 * GET    /api/client_services.php              - Get all services
 * GET    /api/client_services.php?id=X         - Get single service
 * GET    /api/client_services.php?client_id=X  - Get services for a client
 * GET    /api/client_services.php?renewals=30  - Get services expiring in X days
 * POST   /api/client_services.php              - Create service
 * PUT    /api/client_services.php?id=X         - Update service
 * DELETE /api/client_services.php?id=X         - Delete service
 */

// CORS headers for cross-origin requests
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'config.php';

$db = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? intval($_GET['id']) : null;
$clientId = isset($_GET['client_id']) ? intval($_GET['client_id']) : null;
$renewalsDays = isset($_GET['renewals']) ? intval($_GET['renewals']) : null;

switch ($method) {
    case 'GET':
        if ($id) {
            getService($db, $id);
        } elseif ($clientId) {
            getServicesByClient($db, $clientId);
        } elseif ($renewalsDays !== null) {
            getUpcomingRenewals($db, $renewalsDays);
        } else {
            getAllServices($db);
        }
        break;
    case 'POST':
        createService($db);
        break;
    case 'PUT':
        if ($id) {
            updateService($db, $id);
        } else {
            jsonResponse(['error' => 'Service ID required'], 400);
        }
        break;
    case 'DELETE':
        if ($id) {
            deleteService($db, $id);
        } else {
            jsonResponse(['error' => 'Service ID required'], 400);
        }
        break;
    default:
        jsonResponse(['error' => 'Method not allowed'], 405);
}

function calculateStatus($endDate) {
    $today = new DateTime();
    $end = new DateTime($endDate);
    $diff = $today->diff($end);
    $daysRemaining = $diff->invert ? -$diff->days : $diff->days;
    
    if ($daysRemaining < 0) {
        return 'expired';
    } elseif ($daysRemaining <= 30) {
        return 'expiring_soon';
    }
    return 'active';
}

function getAllServices($db) {
    $stmt = $db->query("
        SELECT s.*, c.name as client_name, c.company_name as client_company
        FROM client_services s
        LEFT JOIN clients c ON s.client_id = c.id
        ORDER BY s.end_date ASC
    ");
    $services = $stmt->fetchAll();
    
    // Update status based on dates
    foreach ($services as &$service) {
        $service['status'] = calculateStatus($service['end_date']);
    }
    
    jsonResponse($services);
}

function getService($db, $id) {
    $stmt = $db->prepare("
        SELECT s.*, c.name as client_name, c.company_name as client_company
        FROM client_services s
        LEFT JOIN clients c ON s.client_id = c.id
        WHERE s.id = ?
    ");
    $stmt->execute([$id]);
    $service = $stmt->fetch();
    
    if ($service) {
        $service['status'] = calculateStatus($service['end_date']);
        jsonResponse($service);
    } else {
        jsonResponse(['error' => 'Service not found'], 404);
    }
}

function getServicesByClient($db, $clientId) {
    $stmt = $db->prepare("
        SELECT s.*, c.name as client_name, c.company_name as client_company
        FROM client_services s
        LEFT JOIN clients c ON s.client_id = c.id
        WHERE s.client_id = ?
        ORDER BY s.end_date ASC
    ");
    $stmt->execute([$clientId]);
    $services = $stmt->fetchAll();
    
    foreach ($services as &$service) {
        $service['status'] = calculateStatus($service['end_date']);
    }
    
    jsonResponse($services);
}

function getUpcomingRenewals($db, $days) {
    $futureDate = date('Y-m-d', strtotime("+$days days"));
    $today = date('Y-m-d');
    
    $stmt = $db->prepare("
        SELECT s.*, c.name as client_name, c.company_name as client_company
        FROM client_services s
        LEFT JOIN clients c ON s.client_id = c.id
        WHERE s.end_date BETWEEN ? AND ?
        ORDER BY s.end_date ASC
    ");
    $stmt->execute([$today, $futureDate]);
    $services = $stmt->fetchAll();
    
    foreach ($services as &$service) {
        $service['status'] = 'expiring_soon';
    }
    
    jsonResponse($services);
}

function createService($db) {
    $data = getJsonInput();
    
    $required = ['client_id', 'service_type', 'service_name', 'start_date', 'end_date'];
    $missing = validateRequired($data, $required);
    if (!empty($missing)) {
        jsonResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
    }
    
    // Verify client exists
    $stmt = $db->prepare("SELECT id FROM clients WHERE id = ?");
    $stmt->execute([intval($data['client_id'])]);
    if (!$stmt->fetch()) {
        jsonResponse(['error' => 'Client not found'], 404);
    }
    
    // Verify invoice exists if provided
    if (!empty($data['invoice_id'])) {
        $stmt = $db->prepare("SELECT id FROM invoices WHERE id = ?");
        $stmt->execute([$data['invoice_id']]);
        if (!$stmt->fetch()) {
            jsonResponse(['error' => 'Invoice not found'], 404);
        }
    }
    
    $status = calculateStatus($data['end_date']);
    
    $stmt = $db->prepare("
        INSERT INTO client_services (
            client_id, service_type, service_name, start_date, end_date,
            price, currency, status, invoice_id, notes, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    
    $stmt->execute([
        intval($data['client_id']),
        sanitizeString($data['service_type'], 100),
        sanitizeString($data['service_name'], 255),
        sanitizeString($data['start_date'], 20),
        sanitizeString($data['end_date'], 20),
        floatval($data['price'] ?? 0),
        sanitizeString($data['currency'] ?? 'USD', 10),
        $status,
        !empty($data['invoice_id']) ? sanitizeString($data['invoice_id'], 50) : null,
        sanitizeString($data['notes'] ?? '', 2000)
    ]);
    
    $newId = $db->lastInsertId();
    
    // Return the created service
    $stmt = $db->prepare("
        SELECT s.*, c.name as client_name, c.company_name as client_company
        FROM client_services s
        LEFT JOIN clients c ON s.client_id = c.id
        WHERE s.id = ?
    ");
    $stmt->execute([$newId]);
    $service = $stmt->fetch();
    
    jsonResponse($service, 201);
}

function updateService($db, $id) {
    $data = getJsonInput();
    
    // Check if service exists
    $stmt = $db->prepare("SELECT id FROM client_services WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        jsonResponse(['error' => 'Service not found'], 404);
    }
    
    // Verify client exists if updating
    if (isset($data['client_id'])) {
        $stmt = $db->prepare("SELECT id FROM clients WHERE id = ?");
        $stmt->execute([intval($data['client_id'])]);
        if (!$stmt->fetch()) {
            jsonResponse(['error' => 'Client not found'], 404);
        }
    }
    
    // Build update query
    $fields = [];
    $values = [];
    
    $stringFields = [
        'service_type' => 100, 
        'service_name' => 255, 
        'start_date' => 20, 
        'end_date' => 20,
        'currency' => 10,
        'invoice_id' => 50,
        'notes' => 2000
    ];
    $numericFields = ['client_id', 'price'];
    
    foreach ($stringFields as $field => $maxLen) {
        if (isset($data[$field])) {
            $fields[] = "$field = ?";
            $values[] = sanitizeString($data[$field], $maxLen);
        }
    }
    
    foreach ($numericFields as $field) {
        if (isset($data[$field])) {
            $fields[] = "$field = ?";
            $values[] = floatval($data[$field]);
        }
    }
    
    // Update status based on end_date
    if (isset($data['end_date'])) {
        $fields[] = "status = ?";
        $values[] = calculateStatus($data['end_date']);
    }
    
    if (empty($fields)) {
        jsonResponse(['error' => 'No fields to update'], 400);
    }
    
    $values[] = $id;
    $sql = "UPDATE client_services SET " . implode(', ', $fields) . " WHERE id = ?";
    $stmt = $db->prepare($sql);
    $stmt->execute($values);
    
    // Return updated service
    $stmt = $db->prepare("
        SELECT s.*, c.name as client_name, c.company_name as client_company
        FROM client_services s
        LEFT JOIN clients c ON s.client_id = c.id
        WHERE s.id = ?
    ");
    $stmt->execute([$id]);
    $service = $stmt->fetch();
    $service['status'] = calculateStatus($service['end_date']);
    
    jsonResponse($service);
}

function deleteService($db, $id) {
    $stmt = $db->prepare("SELECT id FROM client_services WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        jsonResponse(['error' => 'Service not found'], 404);
    }
    
    $stmt = $db->prepare("DELETE FROM client_services WHERE id = ?");
    $stmt->execute([$id]);
    
    jsonResponse(['message' => 'Service deleted successfully']);
}
?>
