<?php
/**
 * Templates API Endpoints
 * GET    /api/templates.php         - Get all templates
 * GET    /api/templates.php?id=X    - Get single template
 * POST   /api/templates.php         - Create template
 * PUT    /api/templates.php?id=X    - Update template
 * DELETE /api/templates.php?id=X    - Delete template
 */

require_once 'config.php';

$db = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? intval($_GET['id']) : null;

switch ($method) {
    case 'GET':
        if ($id) {
            getTemplate($db, $id);
        } else {
            getAllTemplates($db);
        }
        break;
    case 'POST':
        createTemplate($db);
        break;
    case 'PUT':
        if ($id) {
            updateTemplate($db, $id);
        } else {
            jsonResponse(['error' => 'Template ID required'], 400);
        }
        break;
    case 'DELETE':
        if ($id) {
            deleteTemplate($db, $id);
        } else {
            jsonResponse(['error' => 'Template ID required'], 400);
        }
        break;
    default:
        jsonResponse(['error' => 'Method not allowed'], 405);
}

function getAllTemplates($db) {
    $stmt = $db->query("SELECT * FROM templates ORDER BY created_at DESC");
    $templates = $stmt->fetchAll();
    
    foreach ($templates as &$template) {
        $template['signature_info'] = json_decode($template['signature_info'], true);
        $template['company_info'] = json_decode($template['company_info'], true);
        $template['payment_info'] = json_decode($template['payment_info'], true);
    }
    
    jsonResponse($templates);
}

function getTemplate($db, $id) {
    $stmt = $db->prepare("SELECT * FROM templates WHERE id = ?");
    $stmt->execute([$id]);
    $template = $stmt->fetch();
    
    if ($template) {
        $template['signature_info'] = json_decode($template['signature_info'], true);
        $template['company_info'] = json_decode($template['company_info'], true);
        $template['payment_info'] = json_decode($template['payment_info'], true);
        jsonResponse($template);
    } else {
        jsonResponse(['error' => 'Template not found'], 404);
    }
}

function createTemplate($db) {
    $data = getJsonInput();
    
    // Validate required fields
    $required = ['name'];
    $missing = validateRequired($data, $required);
    if (!empty($missing)) {
        jsonResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
    }
    
    $stmt = $db->prepare("
        INSERT INTO templates (
            name, client_notes, terms, thank_you_message,
            signature_info, company_info, payment_info, is_default, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    
    $stmt->execute([
        sanitizeString($data['name'], 255),
        $data['client_notes'] ?? null,
        $data['terms'] ?? null,
        sanitizeString($data['thank_you_message'] ?? '', 500),
        isset($data['signature_info']) ? json_encode($data['signature_info']) : null,
        isset($data['company_info']) ? json_encode($data['company_info']) : null,
        isset($data['payment_info']) ? json_encode($data['payment_info']) : null,
        isset($data['is_default']) ? ($data['is_default'] ? 1 : 0) : 0
    ]);
    
    $newId = $db->lastInsertId();
    
    // If this is set as default, unset other defaults
    if (isset($data['is_default']) && $data['is_default']) {
        $stmt = $db->prepare("UPDATE templates SET is_default = 0 WHERE id != ?");
        $stmt->execute([$newId]);
    }
    
    // Return the created template
    $stmt = $db->prepare("SELECT * FROM templates WHERE id = ?");
    $stmt->execute([$newId]);
    $template = $stmt->fetch();
    
    if ($template) {
        $template['signature_info'] = json_decode($template['signature_info'], true);
        $template['company_info'] = json_decode($template['company_info'], true);
        $template['payment_info'] = json_decode($template['payment_info'], true);
    }
    
    jsonResponse($template, 201);
}

function updateTemplate($db, $id) {
    $data = getJsonInput();
    
    // Check if template exists
    $stmt = $db->prepare("SELECT id FROM templates WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        jsonResponse(['error' => 'Template not found'], 404);
    }
    
    // Build update query
    $fields = [];
    $values = [];
    
    $stringFields = ['name' => 255, 'thank_you_message' => 500];
    $textFields = ['client_notes', 'terms'];
    $jsonFields = ['signature_info', 'company_info', 'payment_info'];
    
    foreach ($stringFields as $field => $maxLen) {
        if (isset($data[$field])) {
            $fields[] = "$field = ?";
            $values[] = sanitizeString($data[$field], $maxLen);
        }
    }
    
    foreach ($textFields as $field) {
        if (isset($data[$field])) {
            $fields[] = "$field = ?";
            $values[] = $data[$field]; // Allow full text content
        }
    }
    
    foreach ($jsonFields as $field) {
        if (isset($data[$field])) {
            $fields[] = "$field = ?";
            $values[] = json_encode($data[$field]);
        }
    }
    
    if (isset($data['is_default'])) {
        $fields[] = "is_default = ?";
        $values[] = $data['is_default'] ? 1 : 0;
        
        // If setting as default, unset others
        if ($data['is_default']) {
            $stmt = $db->prepare("UPDATE templates SET is_default = 0 WHERE id != ?");
            $stmt->execute([$id]);
        }
    }
    
    if (empty($fields)) {
        jsonResponse(['error' => 'No fields to update'], 400);
    }
    
    $values[] = $id;
    $sql = "UPDATE templates SET " . implode(', ', $fields) . " WHERE id = ?";
    $stmt = $db->prepare($sql);
    $stmt->execute($values);
    
    // Return updated template
    $stmt = $db->prepare("SELECT * FROM templates WHERE id = ?");
    $stmt->execute([$id]);
    $template = $stmt->fetch();
    
    if ($template) {
        $template['signature_info'] = json_decode($template['signature_info'], true);
        $template['company_info'] = json_decode($template['company_info'], true);
        $template['payment_info'] = json_decode($template['payment_info'], true);
    }
    
    jsonResponse($template);
}

function deleteTemplate($db, $id) {
    $stmt = $db->prepare("SELECT id FROM templates WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        jsonResponse(['error' => 'Template not found'], 404);
    }
    
    $stmt = $db->prepare("DELETE FROM templates WHERE id = ?");
    $stmt->execute([$id]);
    
    jsonResponse(['message' => 'Template deleted successfully']);
}
?>
