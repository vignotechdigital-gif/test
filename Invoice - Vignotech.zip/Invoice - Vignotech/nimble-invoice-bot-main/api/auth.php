<?php
/**
 * Authentication API - Simple login with PHP sessions
 */

require_once __DIR__ . '/config.php';

// Start session with secure settings
session_set_cookie_params([
    'lifetime' => 86400, // 24 hours
    'path' => '/',
    'secure' => isset($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Lax'
]);
session_start();

$method = $_SERVER['REQUEST_METHOD'];

// Route based on action parameter
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'login':
        if ($method === 'POST') {
            handleLogin();
        } else {
            jsonResponse(['error' => 'Method not allowed'], 405);
        }
        break;
    
    case 'logout':
        handleLogout();
        break;
    
    case 'check':
        checkSession();
        break;
    
    case 'user':
        getUser();
        break;
    
    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}

/**
 * Handle user login
 */
function handleLogin() {
    $data = getJsonInput();
    
    $missing = validateRequired($data, ['email', 'password']);
    if (!empty($missing)) {
        jsonResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
    }
    
    $email = sanitizeEmail($data['email']);
    if (!$email) {
        jsonResponse(['error' => 'Invalid email format'], 400);
    }
    
    $password = $data['password'];
    
    $pdo = getDBConnection();
    
    try {
        $stmt = $pdo->prepare("SELECT id, email, name, password_hash, created_at FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if (!$user) {
            jsonResponse(['error' => 'Invalid email or password'], 401);
        }
        
        if (!password_verify($password, $user['password_hash'])) {
            jsonResponse(['error' => 'Invalid email or password'], 401);
        }
        
        // Set session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['logged_in'] = true;
        
        // Return user data (without password)
        jsonResponse([
            'success' => true,
            'user' => [
                'id' => $user['id'],
                'email' => $user['email'],
                'name' => $user['name'],
                'createdAt' => $user['created_at']
            ]
        ]);
        
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Login failed: ' . $e->getMessage()], 500);
    }
}

/**
 * Handle user logout
 */
function handleLogout() {
    $_SESSION = [];
    
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    session_destroy();
    
    jsonResponse(['success' => true, 'message' => 'Logged out successfully']);
}

/**
 * Check if user is logged in
 */
function checkSession() {
    if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
        jsonResponse([
            'authenticated' => true,
            'user' => [
                'id' => $_SESSION['user_id'],
                'email' => $_SESSION['user_email'],
                'name' => $_SESSION['user_name']
            ]
        ]);
    } else {
        jsonResponse(['authenticated' => false]);
    }
}

/**
 * Get current user info
 */
function getUser() {
    if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
        jsonResponse(['error' => 'Not authenticated'], 401);
    }
    
    jsonResponse([
        'user' => [
            'id' => $_SESSION['user_id'],
            'email' => $_SESSION['user_email'],
            'name' => $_SESSION['user_name']
        ]
    ]);
}
?>
