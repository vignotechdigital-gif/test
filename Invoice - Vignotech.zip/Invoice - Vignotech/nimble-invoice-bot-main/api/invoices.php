<?php
/**
 * Invoices API Endpoints
 * GET    /api/invoices.php              - Get all invoices
 * GET    /api/invoices.php?id=X         - Get single invoice
 * GET    /api/invoices.php?next_number  - Get next invoice number
 * POST   /api/invoices.php              - Create invoice
 * PUT    /api/invoices.php?id=X         - Update invoice
 * DELETE /api/invoices.php?id=X         - Delete invoice
 */

require_once 'config.php';

$db = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? sanitizeString($_GET['id'], 50) : null;

switch ($method) {
    case 'GET':
        if (isset($_GET['next_number'])) {
            getNextInvoiceNumber($db);
        } elseif ($id) {
            getInvoice($db, $id);
        } else {
            getAllInvoices($db);
        }
        break;
    case 'POST':
        createInvoice($db);
        break;
    case 'PUT':
        if ($id) {
            updateInvoice($db, $id);
        } else {
            jsonResponse(['error' => 'Invoice ID required'], 400);
        }
        break;
    case 'DELETE':
        if ($id) {
            deleteInvoice($db, $id);
        } else {
            jsonResponse(['error' => 'Invoice ID required'], 400);
        }
        break;
    default:
        jsonResponse(['error' => 'Method not allowed'], 405);
}

function getAllInvoices($db) {
    $stmt = $db->query("SELECT * FROM invoices ORDER BY created_at DESC");
    $invoices = $stmt->fetchAll();
    
    // Decode JSON fields
    foreach ($invoices as &$invoice) {
        $invoice['items'] = json_decode($invoice['items'], true) ?? [];
        $invoice['client'] = json_decode($invoice['client'], true) ?? [];
        $invoice['company'] = json_decode($invoice['company'], true) ?? [];
        $invoice['payment_info'] = json_decode($invoice['payment_info'], true);
        $invoice['invoice_notes'] = json_decode($invoice['invoice_notes'], true);
        $invoice['signature'] = json_decode($invoice['signature'], true);
    }
    
    jsonResponse($invoices);
}

function getInvoice($db, $id) {
    $stmt = $db->prepare("SELECT * FROM invoices WHERE id = ?");
    $stmt->execute([$id]);
    $invoice = $stmt->fetch();
    
    if ($invoice) {
        // Decode JSON fields
        $invoice['items'] = json_decode($invoice['items'], true) ?? [];
        $invoice['client'] = json_decode($invoice['client'], true) ?? [];
        $invoice['company'] = json_decode($invoice['company'], true) ?? [];
        $invoice['payment_info'] = json_decode($invoice['payment_info'], true);
        $invoice['invoice_notes'] = json_decode($invoice['invoice_notes'], true);
        $invoice['signature'] = json_decode($invoice['signature'], true);
        jsonResponse($invoice);
    } else {
        jsonResponse(['error' => 'Invoice not found'], 404);
    }
}

function getNextInvoiceNumber($db) {
    $stmt = $db->query("SELECT invoice_number FROM invoices ORDER BY created_at DESC LIMIT 1");
    $last = $stmt->fetch();
    
    if ($last) {
        // Extract number from format INV-0001
        preg_match('/\d+/', $last['invoice_number'], $matches);
        $nextNum = isset($matches[0]) ? intval($matches[0]) + 1 : 1;
    } else {
        $nextNum = 1;
    }
    
    jsonResponse(['next_number' => 'INV-' . str_pad($nextNum, 4, '0', STR_PAD_LEFT)]);
}

function createInvoice($db) {
    $data = getJsonInput();
    
    // Validate required fields
    $required = ['id', 'invoice_number', 'date', 'due_date', 'client', 'company', 'items', 'currency', 'total', 'status'];
    $missing = validateRequired($data, $required);
    if (!empty($missing)) {
        jsonResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
    }
    
    try {
        $stmt = $db->prepare("
            INSERT INTO invoices (
                id, invoice_number, date, due_date, client, company, items,
                currency, subtotal, tax_rate, tax_amount, discount_type,
                discount_value, discount_amount, total, notes, terms,
                payment_info, invoice_notes, signature, status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            sanitizeString($data['id'], 50),
            sanitizeString($data['invoice_number'], 50),
            sanitizeString($data['date'], 20),
            sanitizeString($data['due_date'], 20),
            json_encode($data['client']),
            json_encode($data['company']),
            json_encode($data['items']),
            sanitizeString($data['currency'], 10),
            floatval($data['subtotal'] ?? 0),
            floatval($data['tax_rate'] ?? 0),
            floatval($data['tax_amount'] ?? 0),
            sanitizeString($data['discount_type'] ?? 'percentage', 20),
            floatval($data['discount_value'] ?? 0),
            floatval($data['discount_amount'] ?? 0),
            floatval($data['total']),
            $data['notes'] ?? '',  // TEXT fields - don't limit length
            $data['terms'] ?? '',  // TEXT fields - don't limit length
            isset($data['payment_info']) ? json_encode($data['payment_info']) : null,
            isset($data['invoice_notes']) ? json_encode($data['invoice_notes']) : null,
            isset($data['signature']) ? json_encode($data['signature']) : null,
            sanitizeString($data['status'], 20)
        ]);
        
        // Return the created invoice
        $stmt = $db->prepare("SELECT * FROM invoices WHERE id = ?");
        $stmt->execute([$data['id']]);
        $invoice = $stmt->fetch();
        
        if ($invoice) {
            $invoice['items'] = json_decode($invoice['items'], true) ?? [];
            $invoice['client'] = json_decode($invoice['client'], true) ?? [];
            $invoice['company'] = json_decode($invoice['company'], true) ?? [];
            $invoice['payment_info'] = json_decode($invoice['payment_info'], true);
            $invoice['invoice_notes'] = json_decode($invoice['invoice_notes'], true);
            $invoice['signature'] = json_decode($invoice['signature'], true);
        }
        
        jsonResponse($invoice, 201);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
    }
}

function updateInvoice($db, $id) {
    $data = getJsonInput();
    
    // Check if invoice exists
    $stmt = $db->prepare("SELECT id FROM invoices WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        jsonResponse(['error' => 'Invoice not found'], 404);
    }
    
    // Build update query
    $fields = [];
    $values = [];
    
    $stringFields = ['invoice_number' => 50, 'date' => 20, 'due_date' => 20, 'currency' => 10, 'status' => 20, 'notes' => 2000, 'terms' => 2000, 'discount_type' => 20];
    $numericFields = ['subtotal', 'tax_rate', 'tax_amount', 'discount_value', 'discount_amount', 'total'];
    $jsonFields = ['client', 'company', 'items', 'payment_info', 'invoice_notes', 'signature'];
    
    foreach ($stringFields as $field => $maxLen) {
        if (isset($data[$field])) {
            $fields[] = "$field = ?";
            $values[] = sanitizeString($data[$field], $maxLen);
        }
    }
    
    foreach ($numericFields as $field) {
        if (isset($data[$field])) {
            $fields[] = "$field = ?";
            $values[] = floatval($data[$field]);
        }
    }
    
    foreach ($jsonFields as $field) {
        if (isset($data[$field])) {
            $fields[] = "$field = ?";
            $values[] = json_encode($data[$field]);
        }
    }
    
    if (empty($fields)) {
        jsonResponse(['error' => 'No fields to update'], 400);
    }
    
    $values[] = $id;
    $sql = "UPDATE invoices SET " . implode(', ', $fields) . " WHERE id = ?";
    $stmt = $db->prepare($sql);
    $stmt->execute($values);
    
    // Return updated invoice
    $stmt = $db->prepare("SELECT * FROM invoices WHERE id = ?");
    $stmt->execute([$id]);
    $invoice = $stmt->fetch();
    
    if ($invoice) {
        $invoice['items'] = json_decode($invoice['items'], true) ?? [];
        $invoice['client'] = json_decode($invoice['client'], true) ?? [];
        $invoice['company'] = json_decode($invoice['company'], true) ?? [];
        $invoice['payment_info'] = json_decode($invoice['payment_info'], true);
        $invoice['invoice_notes'] = json_decode($invoice['invoice_notes'], true);
        $invoice['signature'] = json_decode($invoice['signature'], true);
    }
    
    jsonResponse($invoice);
}

function deleteInvoice($db, $id) {
    $stmt = $db->prepare("SELECT id FROM invoices WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        jsonResponse(['error' => 'Invoice not found'], 404);
    }
    
    $stmt = $db->prepare("DELETE FROM invoices WHERE id = ?");
    $stmt->execute([$id]);
    
    jsonResponse(['message' => 'Invoice deleted successfully']);
}
?>
