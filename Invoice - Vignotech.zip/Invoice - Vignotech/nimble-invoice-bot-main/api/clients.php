<?php
/**
 * Clients API Endpoints
 * GET    /api/clients.php         - Get all clients
 * GET    /api/clients.php?id=X    - Get single client
 * POST   /api/clients.php         - Create client
 * PUT    /api/clients.php?id=X    - Update client
 * DELETE /api/clients.php?id=X    - Delete client
 */

require_once 'config.php';

$db = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? intval($_GET['id']) : null;

switch ($method) {
    case 'GET':
        if ($id) {
            getClient($db, $id);
        } else {
            getAllClients($db);
        }
        break;
    case 'POST':
        createClient($db);
        break;
    case 'PUT':
        if ($id) {
            updateClient($db, $id);
        } else {
            jsonResponse(['error' => 'Client ID required'], 400);
        }
        break;
    case 'DELETE':
        if ($id) {
            deleteClient($db, $id);
        } else {
            jsonResponse(['error' => 'Client ID required'], 400);
        }
        break;
    default:
        jsonResponse(['error' => 'Method not allowed'], 405);
}

function getAllClients($db) {
    $stmt = $db->query("SELECT * FROM clients ORDER BY created_at DESC");
    $clients = $stmt->fetchAll();
    jsonResponse($clients);
}

function getClient($db, $id) {
    $stmt = $db->prepare("SELECT * FROM clients WHERE id = ?");
    $stmt->execute([$id]);
    $client = $stmt->fetch();
    
    if ($client) {
        jsonResponse($client);
    } else {
        jsonResponse(['error' => 'Client not found'], 404);
    }
}

function createClient($db) {
    try {
        $data = getJsonInput();
        
        // Validate required fields
        $required = ['name', 'email', 'address_line1', 'city', 'country'];
        $missing = validateRequired($data, $required);
        if (!empty($missing)) {
            jsonResponse(['error' => 'Missing required fields: ' . implode(', ', $missing)], 400);
        }
        
        // Validate email
        $email = sanitizeEmail($data['email']);
        if (!$email) {
            jsonResponse(['error' => 'Invalid email address'], 400);
        }
        
        $stmt = $db->prepare("
            INSERT INTO clients (
                name, company_name, email, phone,
                address_line1, address_line2, city, state_province,
                postal_code, country, country_code, tax_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            sanitizeString($data['name'], 255),
            sanitizeString($data['company_name'] ?? '', 255),
            $email,
            sanitizeString($data['phone'] ?? '', 50),
            $data['address_line1'] ?? '',
            $data['address_line2'] ?? '',
            sanitizeString($data['city'], 100),
            sanitizeString($data['state_province'] ?? '', 100),
            sanitizeString($data['postal_code'] ?? '', 20),
            sanitizeString($data['country'], 100),
            sanitizeString($data['country_code'] ?? '', 10),
            sanitizeString($data['tax_id'] ?? '', 50)
        ]);
        
        $newId = $db->lastInsertId();
        
        // Return the created client
        $stmt = $db->prepare("SELECT * FROM clients WHERE id = ?");
        $stmt->execute([$newId]);
        $client = $stmt->fetch();
        
        jsonResponse($client, 201);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Database error: ' . $e->getMessage()], 500);
    } catch (Exception $e) {
        jsonResponse(['error' => 'Server error: ' . $e->getMessage()], 500);
    }
}

function updateClient($db, $id) {
    $data = getJsonInput();
    
    // Check if client exists
    $stmt = $db->prepare("SELECT id FROM clients WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        jsonResponse(['error' => 'Client not found'], 404);
    }
    
    // Build update query dynamically
    $fields = [];
    $values = [];
    
    $allowedFields = [
        'name' => 255, 'company_name' => 255, 'email' => 255, 'phone' => 50,
        'address_line1' => 500, 'address_line2' => 500, 'city' => 100,
        'state_province' => 100, 'postal_code' => 20, 'country' => 100,
        'country_code' => 10, 'tax_id' => 50
    ];
    
    foreach ($allowedFields as $field => $maxLen) {
        if (isset($data[$field])) {
            if ($field === 'email') {
                $email = sanitizeEmail($data['email']);
                if (!$email) {
                    jsonResponse(['error' => 'Invalid email address'], 400);
                }
                $fields[] = "email = ?";
                $values[] = $email;
            } else {
                $fields[] = "$field = ?";
                $values[] = sanitizeString($data[$field], $maxLen);
            }
        }
    }
    
    if (empty($fields)) {
        jsonResponse(['error' => 'No fields to update'], 400);
    }
    
    $values[] = $id;
    $sql = "UPDATE clients SET " . implode(', ', $fields) . " WHERE id = ?";
    $stmt = $db->prepare($sql);
    $stmt->execute($values);
    
    // Return updated client
    $stmt = $db->prepare("SELECT * FROM clients WHERE id = ?");
    $stmt->execute([$id]);
    $client = $stmt->fetch();
    
    jsonResponse($client);
}

function deleteClient($db, $id) {
    // Check if client exists
    $stmt = $db->prepare("SELECT id FROM clients WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        jsonResponse(['error' => 'Client not found'], 404);
    }
    
    // Check if client has invoices
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM invoices WHERE client_id = ?");
    $stmt->execute([$id]);
    $result = $stmt->fetch();
    if ($result['count'] > 0) {
        jsonResponse(['error' => 'Cannot delete client with existing invoices'], 400);
    }
    
    $stmt = $db->prepare("DELETE FROM clients WHERE id = ?");
    $stmt->execute([$id]);
    
    jsonResponse(['message' => 'Client deleted successfully']);
}
?>
