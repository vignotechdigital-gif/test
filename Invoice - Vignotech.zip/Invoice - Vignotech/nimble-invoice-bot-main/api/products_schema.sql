-- =====================================================
-- Products Table Schema for MariaDB
-- Run this SQL in cPanel's phpMyAdmin
-- =====================================================

-- Products Table
CREATE TABLE IF NOT EXISTS products (
    id VARCHAR(50) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    default_rate DECIMAL(15, 2) DEFAULT 0,
    default_quantity INT DEFAULT 1,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_title (title),
    INDEX idx_sort_order (sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Insert Default Products
-- =====================================================

INSERT INTO products (id, title, description, default_rate, default_quantity, sort_order) VALUES
('domain-3yr', 'Domain - 3 years validity', '• Domain ending with .com as per client\'s requirement', 0, 1, 1),

('hosting-3yr', 'Hosting - 3 years', '• Unlimited Disk NVMe
• Unlimited Bandwidth + Emails
• Unlimited Sites + FTP
• Powerful cPanel
• Unlimited Websites
• 1,50,000 Monthly Visitors
• Lifetime Free SSL
• Support 24x7x365
• DNS Management
• 1-click WordPress install
• Unlimited FTP Accounts
• Mail Channel Email Filters
• Application Firewall
• Free Website Migration
• WordPress Support
• Vulnerabilities scanner
• PHP MyAdmin
• Multiple PHP Version
• 99.9% Uptime Guarantee', 0, 1, 2),

('web-dev', 'Web Development - Web Development Package', 'Design, development, and deployment of business website.

Includes:
• Custom Web Design
• Contact Form integration
• SEO Setup (Meta tags & Sitemap)
• Mobile/Tablet optimization', 0, 1, 3),

('prod-support-3yr', 'Production Support - 3 Years', '• Resolution of break/fix tickets and critical errors
• Routine server maintenance and security hardening
• Development of new features as per Client\'s requests
• Content updates and frontend visual improvements
• Speed and database optimization', 0, 1, 4),

('ssl-premium', 'SSL Certificate - Premium', '• Extended Validation SSL for enhanced security
• Green address bar with company name
• Highest level of trust indicator', 0, 1, 5),

('email-hosting', 'Email Hosting', '• Professional email with custom domain
• Webmail access + IMAP/POP3
• Spam & virus protection
• 10GB mailbox storage', 0, 1, 6),

('cdn-integration', 'CDN Integration', '• Cloudflare/AWS CDN for faster global loading
• DDoS protection included
• Edge caching for static assets', 0, 1, 7),

('backup-service', 'Backup Service', '• Daily automated backups with 30-day retention
• One-click restore functionality
• Off-site secure storage', 0, 1, 8),

('security-monitoring', 'Security Monitoring', '• 24/7 malware scanning and firewall monitoring
• Real-time threat detection
• Automatic malware removal', 0, 1, 9),

('google-workspace', 'Google Workspace Setup', '• Business email + Drive + Calendar setup
• User account configuration
• DNS records configuration
• Admin console training', 0, 1, 10),

('logo-design', 'Logo Design', '• Professional logo with multiple formats
• 3 initial concepts
• Unlimited revisions
• Source files included (AI, EPS, PNG, SVG)', 0, 1, 11),

('content-writing', 'Content Writing', '• SEO-optimized website copy
• Keyword research included
• Meta descriptions for all pages
• Up to 10 pages', 0, 1, 12),

('ecommerce-integration', 'E-commerce Integration', '• WooCommerce/Shopify setup with payment gateway
• Product upload (up to 50 products)
• Shipping configuration
• Tax settings', 0, 1, 13),

('analytics-setup', 'Analytics & Tracking Setup', '• Google Analytics 4 + Search Console + Tag Manager
• Conversion tracking setup
• Custom dashboard creation
• Monthly reporting template', 0, 1, 14),

('training-session', 'Training Session', '• 1-hour website management training
• Screen recording provided
• Q&A session
• Follow-up support for 1 week', 0, 1, 15),

('rush-delivery', 'Rush Delivery Fee', '• Expedited delivery surcharge
• Priority queue placement
• Dedicated resource allocation', 0, 1, 16),

('annual-maintenance', 'Annual Maintenance Contract', '• Yearly support renewal
• Priority support response
• Monthly health checks
• Security updates included', 0, 1, 17);
