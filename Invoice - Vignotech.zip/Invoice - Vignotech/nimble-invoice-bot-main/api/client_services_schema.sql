-- =====================================================
-- Client Services Table - MariaDB Schema
-- Run this SQL in cPanel's phpMyAdmin to create the table
-- =====================================================

CREATE TABLE IF NOT EXISTS client_services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT NOT NULL,
    service_type VARCHAR(100) NOT NULL,
    service_name VARCHAR(255) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    price DECIMAL(15, 2) DEFAULT 0,
    currency VARCHAR(10) DEFAULT 'USD',
    status ENUM('active', 'expiring_soon', 'expired') DEFAULT 'active',
    invoice_id INT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE SET NULL,
    INDEX idx_client (client_id),
    INDEX idx_status (status),
    INDEX idx_end_date (end_date),
    INDEX idx_service_type (service_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Example data (optional - uncomment to insert sample services)
-- INSERT INTO client_services (client_id, service_type, service_name, start_date, end_date, price, currency, status) VALUES
-- (1, 'Domain', 'example.com', '2024-01-01', '2027-01-01', 25.00, 'USD', 'active'),
-- (1, 'Hosting', 'Premium Hosting Plan', '2024-01-01', '2027-01-01', 150.00, 'USD', 'active');
