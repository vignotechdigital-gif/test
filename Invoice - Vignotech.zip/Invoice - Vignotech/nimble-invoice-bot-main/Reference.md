public_html/
├── index.html          ← from dist/
├── assets/             ← from dist/assets/
│   ├── index-xxxxx.js
│   ├── index-xxxxx.css
│   └── ...
├── favicon.ico         ← from dist/
├── robots.txt          ← from dist/
├── .htaccess           ← from public/.htaccess (COPY MANUALLY)
│
└── api/                ← CREATE this folder, put ALL PHP files here
    ├── config.php
    ├── auth.php
    ├── clients.php
    ├── invoices.php
    ├── products.php
    ├── templates.php
    ├── client_services.php
    └── (schema.sql files are optional - only needed for DB setup)


How It Works
Your app has two deployment options:

Option 1: Everything on the same cPanel domain (simplest)
Upload dist/* contents into public_html/
Create public_html/api/ folder and upload all .php files there
Set VITE_API_URL to nothing (or remove it) before building — the app defaults to /api which will hit yourdomain.com/api/invoices.php automatically
Build with: npm run build
Option 2: Separate domains (your current setup)
Frontend on Netlify/Vercel → calls https://invoice.vignotech.in/api
PHP files on cPanel at invoice.vignotech.in/public_html/api/
Key Steps for Option 1 (All on cPanel)
Before building, update your .env:

VITE_API_URL=/api
Or simply remove the line — the code already defaults to /api

Run npm run build

Upload dist/* to public_html/

Upload api/*.php to public_html/api/

Copy .htaccess to public_html/ (the one in your public/ folder — it already has the rule to skip rewriting /api/ requests)

Update api/config.php — add your cPanel domain to $allowed_origins

That's it! The .htaccess already has RewriteRule ^api/ - [L] which tells Apache: "Don't touch requests to /api/ — let PHP handle them directly."