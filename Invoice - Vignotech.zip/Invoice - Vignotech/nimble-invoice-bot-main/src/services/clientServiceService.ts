/**
 * Client Services Service - API calls for client service management (domains, hosting, etc.)
 */

import { apiGet, apiPost, apiPut, apiDelete } from './api';

export interface ClientService {
  id: number;
  client_id: number;
  service_type: string;
  service_name: string;
  start_date: string;
  end_date: string;
  price: number;
  currency: string;
  status: 'active' | 'expiring_soon' | 'expired';
  invoice_id?: string;
  notes?: string;
  created_at: string;
  // Joined fields
  client_name?: string;
  client_company?: string;
}

const ENDPOINT = 'client_services.php';

/**
 * Get all client services
 */
export async function getAllClientServices(): Promise<ClientService[]> {
  const response = await apiGet<ClientService[]>(ENDPOINT);
  if (response.error) {
    throw new Error(response.error);
  }
  return response.data ?? [];
}

/**
 * Get services for a specific client
 */
export async function getClientServicesByClientId(clientId: number): Promise<ClientService[]> {
  const response = await apiGet<ClientService[]>(`${ENDPOINT}?client_id=${clientId}`);
  if (response.error) {
    throw new Error(response.error);
  }
  return response.data ?? [];
}

/**
 * Get a single service by ID
 */
export async function getClientServiceById(id: number): Promise<ClientService | null> {
  const response = await apiGet<ClientService>(`${ENDPOINT}?id=${id}`);
  if (response.error) {
    throw new Error(response.error);
  }
  return response.data ?? null;
}

/**
 * Get upcoming renewals (services expiring soon)
 */
export async function getUpcomingRenewals(days: number = 30): Promise<ClientService[]> {
  const response = await apiGet<ClientService[]>(`${ENDPOINT}?renewals=${days}`);
  if (response.error) {
    throw new Error(response.error);
  }
  return response.data ?? [];
}

/**
 * Create a new client service
 */
export async function createClientService(
  service: Omit<ClientService, 'id' | 'status' | 'created_at' | 'client_name' | 'client_company'>
): Promise<ClientService> {
  const response = await apiPost<ClientService>(ENDPOINT, service);
  if (response.error) {
    throw new Error(response.error);
  }
  if (!response.data) {
    throw new Error('Failed to create service');
  }
  return response.data;
}

/**
 * Update an existing client service
 */
export async function updateClientService(
  id: number,
  updates: Partial<ClientService>
): Promise<ClientService> {
  const response = await apiPut<ClientService>(`${ENDPOINT}?id=${id}`, updates);
  if (response.error) {
    throw new Error(response.error);
  }
  if (!response.data) {
    throw new Error('Failed to update service');
  }
  return response.data;
}

/**
 * Delete a client service
 */
export async function deleteClientService(id: number): Promise<void> {
  const response = await apiDelete<{ message: string }>(`${ENDPOINT}?id=${id}`);
  if (response.error) {
    throw new Error(response.error);
  }
}
