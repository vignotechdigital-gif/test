/**
 * Invoice Service - API calls for invoice management
 */

import { apiGet, apiPost, apiPut, apiDelete, ApiResponse } from './api';
import { Invoice } from '@/types/invoice';

const ENDPOINT = 'invoices.php';

/**
 * Get all invoices
 */
export async function getAllInvoices(): Promise<ApiResponse<Invoice[]>> {
  return apiGet<Invoice[]>(ENDPOINT);
}

/**
 * Get a single invoice by ID
 */
export async function getInvoiceById(id: string): Promise<ApiResponse<Invoice>> {
  return apiGet<Invoice>(`${ENDPOINT}?id=${encodeURIComponent(id)}`);
}

/**
 * Get the next invoice number
 */
export async function getNextInvoiceNumber(): Promise<ApiResponse<{ next_number: string }>> {
  return apiGet<{ next_number: string }>(`${ENDPOINT}?next_number`);
}

/**
 * Create a new invoice
 */
export async function createInvoice(invoice: Invoice): Promise<ApiResponse<Invoice>> {
  return apiPost<Invoice>(ENDPOINT, invoice);
}

/**
 * Update an existing invoice
 */
export async function updateInvoiceApi(id: string, updates: Partial<Invoice>): Promise<ApiResponse<Invoice>> {
  return apiPut<Invoice>(`${ENDPOINT}?id=${encodeURIComponent(id)}`, updates);
}

/**
 * Delete an invoice
 */
export async function deleteInvoiceApi(id: string): Promise<ApiResponse<{ message: string }>> {
  return apiDelete<{ message: string }>(`${ENDPOINT}?id=${encodeURIComponent(id)}`);
}
