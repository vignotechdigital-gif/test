/**
 * Template Service - API calls for template management
 */

import { apiGet, apiPost, apiPut, apiDelete, ApiResponse } from './api';
import { SignatureInfo, PaymentInfo, CompanyInfo, InvoiceNotes } from '@/types/invoice';

const ENDPOINT = 'templates.php';

export interface Template {
  id: number;
  name: string;
  client_notes?: string;
  terms?: string;
  thank_you_message?: string;
  signature_info?: SignatureInfo;
  company_info?: CompanyInfo;
  payment_info?: PaymentInfo;
  is_default: boolean;
  created_at: string;
}

export interface CreateTemplateData {
  name: string;
  client_notes?: string;
  terms?: string;
  thank_you_message?: string;
  signature_info?: SignatureInfo;
  company_info?: CompanyInfo;
  payment_info?: PaymentInfo;
  is_default?: boolean;
}

/**
 * Get all templates
 */
export async function getAllTemplates(): Promise<ApiResponse<Template[]>> {
  return apiGet<Template[]>(ENDPOINT);
}

/**
 * Get a single template by ID
 */
export async function getTemplateById(id: number): Promise<ApiResponse<Template>> {
  return apiGet<Template>(`${ENDPOINT}?id=${id}`);
}

/**
 * Get default template
 */
export async function getDefaultTemplate(): Promise<ApiResponse<Template | null>> {
  const result = await getAllTemplates();
  if (result.error) return { error: result.error };
  
  const defaultTemplate = result.data?.find(t => t.is_default) || result.data?.[0] || null;
  return { data: defaultTemplate };
}

/**
 * Create a new template
 */
export async function createTemplate(template: CreateTemplateData): Promise<ApiResponse<Template>> {
  return apiPost<Template>(ENDPOINT, template);
}

/**
 * Update an existing template
 */
export async function updateTemplateApi(id: number, updates: Partial<CreateTemplateData>): Promise<ApiResponse<Template>> {
  return apiPut<Template>(`${ENDPOINT}?id=${id}`, updates);
}

/**
 * Delete a template
 */
export async function deleteTemplateApi(id: number): Promise<ApiResponse<{ message: string }>> {
  return apiDelete<{ message: string }>(`${ENDPOINT}?id=${id}`);
}
