/**
 * API Configuration and Base Functions
 * Update API_BASE_URL to match your cPanel domain
 */

// IMPORTANT: Update this to your cPanel domain when deploying
// Example: 'https://yourdomain.com/api'
export const API_BASE_URL = import.meta.env.VITE_API_URL || '/api';

export interface ApiResponse<T> {
  data?: T;
  error?: string;
}

/**
 * Generic fetch wrapper with error handling
 */
async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  try {
    const url = `${API_BASE_URL}/${endpoint}`;
    
    const defaultHeaders: HeadersInit = {
      'Content-Type': 'application/json',
    };

    const response = await fetch(url, {
      ...options,
      headers: {
        ...defaultHeaders,
        ...options.headers,
      },
    });

    // Check Content-Type before parsing
    const contentType = response.headers.get('content-type');
    const text = await response.text();
    
    // Debug logging
    if (!contentType?.includes('application/json')) {
      console.error('Expected JSON but got:', contentType);
      console.error('Response preview:', text.substring(0, 200));
      
      if (text.trim().startsWith('<?php') || text.includes('<html')) {
        return { 
          error: `Server error: PHP is not executing. Check server configuration. Status: ${response.status}` 
        };
      }
      return { error: `Unexpected response format: ${contentType}` };
    }

    // Try parsing JSON
    let data: T;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      console.error('JSON parse error. Response:', text.substring(0, 200));
      return { error: 'Invalid JSON response from server' };
    }

    // Some backends return 200 with an { error: "..." } payload.
    // Treat that as a failure so UI doesn't show success incorrectly.
    if (data && typeof data === 'object' && !Array.isArray(data)) {
      const maybeError = (data as Record<string, unknown>).error;
      if (typeof maybeError === 'string' && maybeError.trim().length > 0) {
        return { error: maybeError };
      }
    }

    if (!response.ok) {
      return { error: (data as { error?: string })?.error || `HTTP error ${response.status}` };
    }

    return { data };
  } catch (error) {
    console.error('API request failed:', error);
    return { error: error instanceof Error ? error.message : 'Network error' };
  }
}

/**
 * GET request
 */
export async function apiGet<T>(endpoint: string): Promise<ApiResponse<T>> {
  return apiRequest<T>(endpoint, { method: 'GET' });
}

/**
 * POST request
 */
export async function apiPost<T>(endpoint: string, body: unknown): Promise<ApiResponse<T>> {
  return apiRequest<T>(endpoint, {
    method: 'POST',
    body: JSON.stringify(body),
  });
}

/**
 * PUT request
 */
export async function apiPut<T>(endpoint: string, body: unknown): Promise<ApiResponse<T>> {
  return apiRequest<T>(endpoint, {
    method: 'PUT',
    body: JSON.stringify(body),
  });
}

/**
 * DELETE request
 */
export async function apiDelete<T>(endpoint: string): Promise<ApiResponse<T>> {
  return apiRequest<T>(endpoint, { method: 'DELETE' });
}

/**
 * Check if API is available (for fallback to localStorage)
 */
export async function isApiAvailable(): Promise<boolean> {
  try {
    const response = await fetch(`${API_BASE_URL}/invoices.php?next_number`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });
    return response.ok;
  } catch {
    return false;
  }
}
