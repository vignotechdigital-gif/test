/**
 * Client Service - API calls for client management
 */

import { apiGet, apiPost, apiPut, apiDelete, ApiResponse } from './api';
import { ClientInfo } from '@/types/invoice';

const ENDPOINT = 'clients.php';

export interface Client extends ClientInfo {
  id: number;
  created_at: string;
}

/**
 * Get all clients
 */
export async function getAllClients(): Promise<ApiResponse<Client[]>> {
  return apiGet<Client[]>(ENDPOINT);
}

/**
 * Get a single client by ID
 */
export async function getClientById(id: number): Promise<ApiResponse<Client>> {
  return apiGet<Client>(`${ENDPOINT}?id=${id}`);
}

/**
 * Create a new client
 */
export async function createClient(client: Omit<ClientInfo, 'id'>): Promise<ApiResponse<Client>> {
  return apiPost<Client>(ENDPOINT, client);
}

/**
 * Update an existing client
 */
export async function updateClientApi(id: number, updates: Partial<ClientInfo>): Promise<ApiResponse<Client>> {
  return apiPut<Client>(`${ENDPOINT}?id=${id}`, updates);
}

/**
 * Delete a client
 */
export async function deleteClientApi(id: number): Promise<ApiResponse<{ message: string }>> {
  return apiDelete<{ message: string }>(`${ENDPOINT}?id=${id}`);
}
