import { apiGet, apiPost, apiPut, apiDelete, API_BASE_URL } from './api';

export interface Product {
  id: string;
  title: string;
  description: string;
  default_rate: number;
  default_quantity: number;
  sort_order: number;
}

// Helper to ensure numeric values
function parseNumeric(value: unknown): number {
  if (typeof value === 'number') return value;
  if (typeof value === 'string') {
    const parsed = parseFloat(value);
    return isNaN(parsed) ? 0 : parsed;
  }
  return 0;
}

export async function getProducts(): Promise<Product[]> {
  const response = await apiGet<Product[]>('products.php');
  if (response.error) {
    throw new Error(response.error);
  }
  const products = response.data ?? [];
  return products.map(p => ({
    ...p,
    default_rate: parseNumeric(p.default_rate),
    default_quantity: parseNumeric(p.default_quantity),
    sort_order: parseNumeric(p.sort_order),
  }));
}

export async function getProduct(id: string): Promise<Product | null> {
  const response = await apiGet<Product>(`products.php?id=${id}`);
  if (response.error) {
    throw new Error(response.error);
  }
  return response.data ?? null;
}

export async function createProduct(product: Omit<Product, 'sort_order'>): Promise<Product> {
  const response = await apiPost<Product>('products.php', product);
  if (response.error) {
    throw new Error(response.error);
  }
  if (!response.data) {
    throw new Error('Failed to create product');
  }
  return response.data;
}

export async function updateProduct(id: string, data: Partial<Product>): Promise<Product> {
  const response = await apiPut<Product>(`products.php?id=${id}`, data);
  if (response.error) {
    throw new Error(response.error);
  }
  if (!response.data) {
    throw new Error('Failed to update product');
  }
  return response.data;
}

export async function deleteProduct(id: string): Promise<void> {
  const response = await apiDelete(`products.php?id=${id}`);
  if (response.error) {
    throw new Error(response.error);
  }
}
