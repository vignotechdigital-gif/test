import { CurrencyCode } from '@/types/invoice';

const ones = [
  '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
  'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
  'Seventeen', 'Eighteen', 'Nineteen'
];

const tens = [
  '', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'
];

const scales = ['', 'Thousand', 'Million', 'Billion', 'Trillion'];

// Indian scales for INR
const indianScales = ['', 'Thousand', 'Lakh', 'Crore'];

const currencyNames: Record<CurrencyCode, { singular: string; plural: string; subunit: string; subunitPlural: string }> = {
  USD: { singular: 'Dollar', plural: 'Dollars', subunit: 'Cent', subunitPlural: 'Cents' },
  EUR: { singular: 'Euro', plural: 'Euros', subunit: 'Cent', subunitPlural: 'Cents' },
  GBP: { singular: 'Pound', plural: 'Pounds', subunit: 'Penny', subunitPlural: 'Pence' },
  INR: { singular: 'Rupee', plural: 'Rupees', subunit: 'Paisa', subunitPlural: 'Paise' },
  AUD: { singular: 'Dollar', plural: 'Dollars', subunit: 'Cent', subunitPlural: 'Cents' },
  CAD: { singular: 'Dollar', plural: 'Dollars', subunit: 'Cent', subunitPlural: 'Cents' },
  JPY: { singular: 'Yen', plural: 'Yen', subunit: '', subunitPlural: '' },
  CNY: { singular: 'Yuan', plural: 'Yuan', subunit: 'Fen', subunitPlural: 'Fen' },
  CHF: { singular: 'Franc', plural: 'Francs', subunit: 'Centime', subunitPlural: 'Centimes' },
  AED: { singular: 'Dirham', plural: 'Dirhams', subunit: 'Fil', subunitPlural: 'Fils' },
};

function convertHundreds(num: number): string {
  let result = '';
  
  if (num >= 100) {
    result += ones[Math.floor(num / 100)] + ' Hundred';
    num %= 100;
    if (num > 0) result += ' ';
  }
  
  if (num >= 20) {
    result += tens[Math.floor(num / 10)];
    num %= 10;
    if (num > 0) result += '-' + ones[num];
  } else if (num > 0) {
    result += ones[num];
  }
  
  return result;
}

function convertToWordsWestern(num: number): string {
  if (num === 0) return 'Zero';
  
  let result = '';
  let scaleIndex = 0;
  
  while (num > 0) {
    const chunk = num % 1000;
    if (chunk > 0) {
      const chunkWords = convertHundreds(chunk);
      if (scaleIndex > 0) {
        result = chunkWords + ' ' + scales[scaleIndex] + (result ? ' ' + result : '');
      } else {
        result = chunkWords + (result ? ' ' + result : '');
      }
    }
    num = Math.floor(num / 1000);
    scaleIndex++;
  }
  
  return result.trim();
}

function convertToWordsIndian(num: number): string {
  if (num === 0) return 'Zero';
  
  let result = '';
  
  // First handle the last 3 digits (hundreds)
  const hundreds = num % 1000;
  if (hundreds > 0) {
    result = convertHundreds(hundreds);
  }
  num = Math.floor(num / 1000);
  
  // Now handle thousands (next 2 digits)
  if (num > 0) {
    const thousands = num % 100;
    if (thousands > 0) {
      result = convertHundreds(thousands) + ' Thousand' + (result ? ' ' + result : '');
    }
    num = Math.floor(num / 100);
  }
  
  // Handle lakhs (next 2 digits)
  if (num > 0) {
    const lakhs = num % 100;
    if (lakhs > 0) {
      result = convertHundreds(lakhs) + ' Lakh' + (result ? ' ' + result : '');
    }
    num = Math.floor(num / 100);
  }
  
  // Handle crores (remaining digits)
  if (num > 0) {
    result = convertToWordsIndian(num) + ' Crore' + (result ? ' ' + result : '');
  }
  
  return result.trim();
}

export function numberToWords(amount: number, currency: CurrencyCode = 'INR'): string {
  if (amount === 0) return 'Zero ' + currencyNames[currency].plural + ' Only';
  
  const isNegative = amount < 0;
  amount = Math.abs(amount);
  
  const wholePart = Math.floor(amount);
  const decimalPart = Math.round((amount - wholePart) * 100);
  
  const currencyInfo = currencyNames[currency];
  const useIndianSystem = currency === 'INR';
  
  const convertFn = useIndianSystem ? convertToWordsIndian : convertToWordsWestern;
  
  let result = '';
  
  if (isNegative) {
    result += 'Negative ';
  }
  
  if (wholePart > 0) {
    result += convertFn(wholePart) + ' ';
    result += wholePart === 1 ? currencyInfo.singular : currencyInfo.plural;
  }
  
  // JPY doesn't have subunits
  if (currency !== 'JPY' && decimalPart > 0) {
    if (wholePart > 0) {
      result += ' and ';
    }
    result += convertToWordsWestern(decimalPart) + ' ';
    result += decimalPart === 1 ? currencyInfo.subunit : currencyInfo.subunitPlural;
  }
  
  result += ' Only';
  
  return result.trim();
}
