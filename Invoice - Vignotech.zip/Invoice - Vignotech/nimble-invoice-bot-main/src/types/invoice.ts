export type DiscountType = 'percentage' | 'fixed';

export interface InvoiceItem {
  id: string;
  title: string;
  description: string;
  quantity: number;
  rate: number;
  discountType: DiscountType;
  discountValue: number;
  discountAmount: number;
  amount: number;
}

export interface ClientInfo {
  name: string;
  companyName?: string;
  email: string;
  phone?: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  stateProvince?: string;
  postalCode?: string;
  country: string;
  countryCode?: string;
  taxId?: string;
}

export interface CompanyInfo {
  name: string;
  email: string;
  address: string;
  city: string;
  country: string;
  phone?: string;
  logo?: string;
}

export interface BankDetails {
  bankName?: string;
  accountName?: string;
  accountNumber?: string;
  ifscCode?: string;
  swiftCode?: string;
  iban?: string;
  branch?: string;
}

export interface PaymentInfo {
  paymentMethods: string[];
  bankDetails?: BankDetails;
  paypalEmail?: string;
  wiseEmail?: string;
  upiId?: string;
  paymentLink?: string;
}

export interface InvoiceNotes {
  internalNotes?: string;
  clientNotes?: string;
  thankYouMessage?: string;
}

export interface SignatureInfo {
  authorizedSignatory?: string;
  designation?: string;
  digitalSignatureUrl?: string;
}

export type CurrencyCode = 'USD' | 'EUR' | 'GBP' | 'INR' | 'AUD' | 'CAD' | 'JPY' | 'CNY' | 'CHF' | 'AED';

export interface CurrencyInfo {
  code: CurrencyCode;
  symbol: string;
  name: string;
}

export const CURRENCIES: CurrencyInfo[] = [
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'GBP', symbol: '£', name: 'British Pound' },
  { code: 'INR', symbol: '₹', name: 'Indian Rupee' },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar' },
  { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar' },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen' },
  { code: 'CNY', symbol: '¥', name: 'Chinese Yuan' },
  { code: 'CHF', symbol: 'CHF', name: 'Swiss Franc' },
  { code: 'AED', symbol: 'د.إ', name: 'UAE Dirham' },
];

export interface Invoice {
  id: string;
  invoiceNumber: string;
  date: string;
  dueDate: string;
  client: ClientInfo;
  company: CompanyInfo;
  items: InvoiceItem[];
  currency: CurrencyCode;
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  discountType: DiscountType;
  discountValue: number;
  discountAmount: number;
  total: number;
  notes?: string;
  terms?: string;
  paymentInfo?: PaymentInfo;
  invoiceNotes?: InvoiceNotes;
  signature?: SignatureInfo;
  status: 'draft' | 'sent' | 'paid' | 'overdue';
  createdAt: string;
}

export type InvoiceStatus = Invoice['status'];
