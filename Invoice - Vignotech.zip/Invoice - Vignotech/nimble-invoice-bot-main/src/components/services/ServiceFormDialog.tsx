import { useEffect, useState, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Loader2, CalendarIcon, Search, ChevronsUpDown, Check } from 'lucide-react';
import { format } from 'date-fns';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import { Calendar } from '@/components/ui/calendar';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { ClientService } from '@/services/clientServiceService';
import { Client } from '@/services/clientService';
import { Invoice } from '@/types/invoice';

const SERVICE_TYPES = [
  'Domain',
  'Hosting',
  'SSL Certificate',
  'Email Hosting',
  'CDN',
  'Maintenance',
  'Support',
  'Backup Service',
  'SEO',
  'Analytics',
  'Other',
];

const CURRENCIES = ['USD', 'EUR', 'GBP', 'INR', 'CAD', 'AUD'];

const serviceSchema = z.object({
  client_id: z.coerce.number().min(1, 'Client is required'),
  service_type: z.string().min(1, 'Service type is required'),
  service_name: z.string().min(1, 'Service name is required').max(255),
  start_date: z.date({ required_error: 'Start date is required' }),
  end_date: z.date({ required_error: 'End date is required' }),
  price: z.coerce.number().min(0, 'Price must be positive'),
  currency: z.string().min(1, 'Currency is required'),
  invoice_id: z.string().optional(),
  notes: z.string().max(2000).optional(),
});

type ServiceFormValues = z.infer<typeof serviceSchema>;

interface ServiceFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  service?: ClientService | null;
  clients: Client[];
  invoices: Invoice[];
  onSubmit: (data: ServiceFormValues) => Promise<void>;
  isLoading?: boolean;
}

export function ServiceFormDialog({
  open,
  onOpenChange,
  service,
  clients,
  invoices,
  onSubmit,
  isLoading,
}: ServiceFormDialogProps) {
  const isEditing = !!service;

  const form = useForm<ServiceFormValues>({
    resolver: zodResolver(serviceSchema),
    defaultValues: {
      client_id: service?.client_id || 0,
      service_type: service?.service_type || '',
      service_name: service?.service_name || '',
      start_date: service?.start_date ? new Date(service.start_date) : undefined,
      end_date: service?.end_date ? new Date(service.end_date) : undefined,
      price: service?.price || 0,
      currency: service?.currency || 'USD',
      invoice_id: service?.invoice_id || '',
      notes: service?.notes || '',
    },
  });

  const selectedClientId = form.watch('client_id');
  const clientInvoices = invoices.filter(inv => {
    // Match invoices that belong to the selected client
    const client = clients.find(c => c.id === selectedClientId);
    return client && inv.client?.email === client.email;
  });

  useEffect(() => {
    if (open) {
      if (service) {
        form.reset({
          client_id: service.client_id,
          service_type: service.service_type,
          service_name: service.service_name,
          start_date: new Date(service.start_date),
          end_date: new Date(service.end_date),
          price: service.price,
          currency: service.currency,
          invoice_id: service.invoice_id || '',
          notes: service.notes || '',
        });
      } else {
        form.reset({
          client_id: 0,
          service_type: '',
          service_name: '',
          start_date: undefined,
          end_date: undefined,
          price: 0,
          currency: 'USD',
          invoice_id: '',
          notes: '',
        });
      }
    }
  }, [open, service, form]);

  const handleSubmit = async (values: ServiceFormValues) => {
    await onSubmit(values);
    form.reset();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>{isEditing ? 'Edit Service' : 'Add Service'}</DialogTitle>
        </DialogHeader>

        <ScrollArea className="max-h-[calc(90vh-120px)] pr-4">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="client_id"
                render={({ field }) => {
                  const [clientOpen, setClientOpen] = useState(false);
                  const [searchQuery, setSearchQuery] = useState('');

                  const selectedClient = clients.find(c => c.id === field.value);
                  
                  const filteredClients = useMemo(() => {
                    if (!searchQuery) return clients;
                    const query = searchQuery.toLowerCase();
                    return clients.filter(
                      (client) =>
                        client.name?.toLowerCase().includes(query) ||
                        client.companyName?.toLowerCase().includes(query) ||
                        client.email?.toLowerCase().includes(query)
                    );
                  }, [clients, searchQuery]);

                  return (
                    <FormItem>
                      <FormLabel>Client *</FormLabel>
                      <Popover open={clientOpen} onOpenChange={setClientOpen}>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              role="combobox"
                              className={cn(
                                'w-full justify-between font-normal',
                                !field.value && 'text-muted-foreground'
                              )}
                            >
                              <div className="flex items-center gap-2 truncate">
                                <Search className="h-4 w-4 shrink-0 opacity-50" />
                                {selectedClient ? (
                                  <span className="truncate">
                                    {selectedClient.name}
                                    {selectedClient.companyName && ` (${selectedClient.companyName})`}
                                  </span>
                                ) : (
                                  'Search clients...'
                                )}
                              </div>
                              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-[350px] p-0" align="start">
                          <Command shouldFilter={false}>
                            <CommandInput
                              placeholder="Search by name, company..."
                              value={searchQuery}
                              onValueChange={setSearchQuery}
                            />
                            <CommandList>
                              <CommandEmpty>No clients found</CommandEmpty>
                              <CommandGroup>
                                {filteredClients.map((client) => (
                                  <CommandItem
                                    key={client.id}
                                    value={client.id.toString()}
                                    onSelect={() => {
                                      field.onChange(client.id);
                                      setClientOpen(false);
                                      setSearchQuery('');
                                    }}
                                  >
                                    <Check
                                      className={cn(
                                        'mr-2 h-4 w-4',
                                        field.value === client.id ? 'opacity-100' : 'opacity-0'
                                      )}
                                    />
                                    <div className="flex-1 min-w-0">
                                      <div className="font-medium truncate">{client.name}</div>
                                      {client.companyName && (
                                        <div className="text-xs text-muted-foreground truncate">
                                          {client.companyName}
                                        </div>
                                      )}
                                    </div>
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  );
                }}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="service_type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Service Type *</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {SERVICE_TYPES.map((type) => (
                            <SelectItem key={type} value={type}>
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="service_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Service Name *</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="e.g., example.com" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="start_date"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Start Date *</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? format(field.value, "PPP") : "Pick a date"}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                            className="p-3 pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="end_date"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>End Date *</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? format(field.value, "PPP") : "Pick a date"}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                            className="p-3 pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Price</FormLabel>
                      <FormControl>
                        <Input {...field} type="number" step="0.01" min="0" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="currency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Currency</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {CURRENCIES.map((curr) => (
                            <SelectItem key={curr} value={curr}>
                              {curr}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="invoice_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Linked Invoice</FormLabel>
                    <Select 
                      onValueChange={(value) => field.onChange(value === 'none' ? '' : value)} 
                      value={field.value || 'none'}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select invoice (optional)" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">No invoice linked</SelectItem>
                        {clientInvoices.map((invoice) => (
                          <SelectItem key={invoice.id} value={invoice.id}>
                            {invoice.invoiceNumber} - {new Intl.NumberFormat('en-US', { 
                              style: 'currency', 
                              currency: invoice.currency 
                            }).format(invoice.total)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        placeholder="Additional notes..."
                        rows={3}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => onOpenChange(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  {isEditing ? 'Update' : 'Create'}
                </Button>
              </div>
            </form>
          </Form>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
