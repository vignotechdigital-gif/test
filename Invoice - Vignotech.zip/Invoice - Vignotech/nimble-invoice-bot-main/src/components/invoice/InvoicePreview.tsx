import { forwardRef } from 'react';
import { format } from 'date-fns';
import { Printer } from 'lucide-react';
import { Invoice, CURRENCIES } from '@/types/invoice';
import { Button } from '@/components/ui/button';
import { numberToWords } from '@/lib/numberToWords';

interface InvoicePreviewProps {
  invoice: Partial<Invoice>;
}

export const InvoicePreview = forwardRef<HTMLDivElement, InvoicePreviewProps>(
  ({ invoice }, ref) => {
    const currencyCode = invoice.currency || 'USD';
    const currencyInfo = CURRENCIES.find(c => c.code === currencyCode) || CURRENCIES[0];
    
    const formatCurrency = (amount: number) => {
      const noDecimalCurrencies = ['JPY'];
      const decimals = noDecimalCurrencies.includes(currencyCode) ? 0 : 2;
      return `${currencyInfo.symbol}${amount.toFixed(decimals)}`;
    };

    const amountInWords = numberToWords(invoice.total || 0, currencyCode);
    const handlePrint = () => {
      window.print();
    };

    // Build client address string
    const buildClientAddress = () => {
      const parts = [];
      if (invoice.client?.addressLine1) parts.push(invoice.client.addressLine1);
      if (invoice.client?.addressLine2) parts.push(invoice.client.addressLine2);
      return parts.join(', ');
    };

    const buildClientLocation = () => {
      const parts = [];
      if (invoice.client?.city) parts.push(invoice.client.city);
      if (invoice.client?.stateProvince) parts.push(invoice.client.stateProvince);
      if (invoice.client?.postalCode) parts.push(invoice.client.postalCode);
      if (invoice.client?.country) parts.push(invoice.client.country);
      return parts.filter(Boolean).join(', ');
    };

    return (
      <div className="relative">
        {/* Print Button - Hidden when printing */}
        <div className="absolute -top-12 right-0 print:hidden">
          <Button onClick={handlePrint} variant="outline" className="gap-2">
            <Printer className="h-4 w-4" />
            Print A4
          </Button>
        </div>
        
        <div
          ref={ref}
          className="bg-card rounded-xl shadow-card p-8 min-h-[800px] animate-scale-in print:shadow-none print:rounded-none print:p-0 print:min-h-0"
          id="invoice-preview"
        >
        {/* Header */}
        <div className="flex justify-between items-start mb-8 pb-6 border-b border-border">
          <div className="flex items-start gap-4">
            {invoice.company?.logo && (
              <img 
                src={invoice.company.logo} 
                alt="Company logo" 
                className="w-16 h-16 object-contain rounded-lg"
              />
            )}
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-1">
                {invoice.company?.name || 'Your Company'}
              </h2>
              <div className="text-sm text-muted-foreground space-y-0.5">
                <p>{invoice.company?.address}</p>
                <p>{invoice.company?.city}, {invoice.company?.country}</p>
                <p>{invoice.company?.email}</p>
                {invoice.company?.phone && <p>{invoice.company.phone}</p>}
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="inline-block px-4 py-2 rounded-lg gradient-primary mb-2">
              <h1 className="text-xl font-bold text-primary-foreground">INVOICE</h1>
            </div>
            <p className="text-lg font-semibold text-foreground">
              {invoice.invoiceNumber || 'INV-0001'}
            </p>
            <p className="text-sm text-muted-foreground mt-1">
              {currencyInfo.code} ({currencyInfo.name})
            </p>
          </div>
        </div>

        {/* Billing Info */}
        <div className="grid grid-cols-2 gap-8 mb-8">
          <div>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
              Bill To
            </h3>
            <div className="text-sm text-foreground space-y-0.5">
              <p className="font-semibold">{invoice.client?.name || 'Client Name'}</p>
              {invoice.client?.companyName && (
                <p className="font-medium text-muted-foreground">{invoice.client.companyName}</p>
              )}
              {buildClientAddress() && (
                <p className="text-muted-foreground">{buildClientAddress()}</p>
              )}
              {buildClientLocation() && (
                <p className="text-muted-foreground">{buildClientLocation()}</p>
              )}
              {invoice.client?.email && (
                <p className="text-muted-foreground">{invoice.client.email}</p>
              )}
              {invoice.client?.phone && (
                <p className="text-muted-foreground">{invoice.client.phone}</p>
              )}
              {invoice.client?.taxId && (
                <p className="text-muted-foreground text-xs mt-1">Tax ID: {invoice.client.taxId}</p>
              )}
            </div>
          </div>
          <div className="text-right">
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Issue Date:</span>
                <span className="font-medium text-foreground">
                  {invoice.date ? format(new Date(invoice.date), 'MMM d, yyyy') : '-'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Due Date:</span>
                <span className="font-medium text-foreground">
                  {invoice.dueDate ? format(new Date(invoice.dueDate), 'MMM d, yyyy') : '-'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Items Table */}
        <div className="mb-8 border border-border rounded-lg overflow-hidden">
          <table className="w-full border-collapse text-base">
            <thead>
              <tr className="bg-muted/50">
                <th className="border border-border px-4 py-3 text-left text-sm font-semibold text-muted-foreground uppercase tracking-wider">Item</th>
                <th className="border border-border px-4 py-3 text-center text-sm font-semibold text-muted-foreground uppercase tracking-wider w-24">Qty</th>
                <th className="border border-border px-4 py-3 text-right text-sm font-semibold text-muted-foreground uppercase tracking-wider w-32">Rate</th>
                <th className="border border-border px-4 py-3 text-right text-sm font-semibold text-muted-foreground uppercase tracking-wider w-32">Amount</th>
              </tr>
            </thead>
            <tbody>
              {invoice.items && invoice.items.length > 0 ? (
                invoice.items.map((item, index) => (
                  <tr key={item.id || index}>
                    <td className="border border-border px-4 py-4">
                      <p className="font-semibold text-foreground text-base">{item.title || '-'}</p>
                      {item.description && (
                        <p className="text-sm text-muted-foreground mt-1 whitespace-pre-line leading-relaxed">{item.description}</p>
                      )}
                      {item.discountAmount > 0 && (
                        <p className="text-sm text-success mt-1 font-medium">
                          Discount: -{formatCurrency(item.discountAmount)}
                        </p>
                      )}
                    </td>
                    <td className="border border-border px-4 py-4 text-center text-base font-medium text-foreground">{item.quantity}</td>
                    <td className="border border-border px-4 py-4 text-right text-base font-medium text-foreground">
                      {formatCurrency(item.rate)}
                    </td>
                    <td className="border border-border px-4 py-4 text-right text-base font-bold text-foreground bg-muted/30">
                      {formatCurrency(item.amount)}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="border border-border px-4 py-8 text-center text-muted-foreground text-base">
                    No items added yet
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Totals */}
        <div className="flex justify-end mb-4">
          <div className="w-80 text-sm">
            {(() => {
              // Calculate gross total (before any discounts) = sum of (qty * rate) + tax on that
              const grossBeforeDiscounts = invoice.items?.reduce((sum, item) => sum + (item.quantity * item.rate), 0) || 0;
              const taxOnGross = grossBeforeDiscounts * ((invoice.taxRate || 0) / 100);
              const grossTotal = grossBeforeDiscounts + taxOnGross;
              
              // Calculate total discount = line-item discounts + invoice-level discount
              const lineItemDiscounts = invoice.items?.reduce((sum, item) => sum + (item.discountAmount || 0), 0) || 0;
              const invoiceDiscount = invoice.discountAmount || 0;
              const totalDiscount = lineItemDiscounts + invoiceDiscount;
              
              return (
                <>
                  {/* Gross Total (before any discounts) */}
                  <div className="flex justify-between py-2">
                    <span className="text-muted-foreground font-medium">Gross Total</span>
                    <span className="font-semibold text-foreground">
                      {formatCurrency(grossTotal)}
                    </span>
                  </div>
                  
                  {/* Total Discount */}
                  <div className={`flex justify-between py-2 px-2 -mx-2 rounded ${totalDiscount > 0 ? 'bg-success/10' : ''}`}>
                    <span className={totalDiscount > 0 ? 'text-success font-medium' : 'text-muted-foreground'}>
                      Discount
                    </span>
                    <span className={totalDiscount > 0 ? 'text-success font-semibold' : 'font-medium text-foreground'}>
                      {totalDiscount > 0 ? `-${formatCurrency(totalDiscount)}` : formatCurrency(0)}
                    </span>
                  </div>
                  
                  {/* Net Total */}
                  <div className="flex justify-between py-3 border-t-2 border-primary/30 mt-2 bg-muted/50 px-2 -mx-2 rounded">
                    <span className="text-lg font-bold text-foreground">Net Total</span>
                    <span className="text-lg font-bold text-primary">{formatCurrency(invoice.total || 0)}</span>
                  </div>
                </>
              );
            })()}
          </div>
        </div>

        {/* Amount in Words */}
        {(invoice.total ?? 0) > 0 && (
          <div className="mb-8 p-3 bg-muted/30 rounded-lg border border-border">
            <p className="text-sm">
              <span className="font-semibold text-foreground">Amount in Words: </span>
              <span className="text-muted-foreground italic">{amountInWords}</span>
            </p>
          </div>
        )}

        {/* Payment Information */}
        {invoice.paymentInfo && invoice.paymentInfo.paymentMethods.length > 0 && (
          <div className="mb-6 p-4 bg-muted/30 rounded-lg border border-border">
            <h4 className="font-semibold text-foreground text-sm mb-3">Payment Information</h4>
            <div className="text-sm text-muted-foreground space-y-2">
              <p><span className="font-medium">Accepted Methods:</span> {invoice.paymentInfo.paymentMethods.join(', ')}</p>
              
              {invoice.paymentInfo.bankDetails && invoice.paymentInfo.paymentMethods.includes('Bank Transfer') && (
                <div className="mt-2 pt-2 border-t border-border/50">
                  <p className="font-medium text-foreground mb-1">Bank Details:</p>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
                    {invoice.paymentInfo.bankDetails.bankName && (
                      <p>Bank: {invoice.paymentInfo.bankDetails.bankName}</p>
                    )}
                    {invoice.paymentInfo.bankDetails.accountName && (
                      <p>Account Name: {invoice.paymentInfo.bankDetails.accountName}</p>
                    )}
                    {invoice.paymentInfo.bankDetails.accountNumber && (
                      <p>Account No: {invoice.paymentInfo.bankDetails.accountNumber}</p>
                    )}
                    {invoice.paymentInfo.bankDetails.branch && (
                      <p>Branch: {invoice.paymentInfo.bankDetails.branch}</p>
                    )}
                    {invoice.paymentInfo.bankDetails.ifscCode && (
                      <p>IFSC: {invoice.paymentInfo.bankDetails.ifscCode}</p>
                    )}
                    {invoice.paymentInfo.bankDetails.swiftCode && (
                      <p>SWIFT: {invoice.paymentInfo.bankDetails.swiftCode}</p>
                    )}
                    {invoice.paymentInfo.bankDetails.iban && (
                      <p className="col-span-2">IBAN: {invoice.paymentInfo.bankDetails.iban}</p>
                    )}
                  </div>
                </div>
              )}
              
              {invoice.paymentInfo.upiId && (
                <p>UPI: {invoice.paymentInfo.upiId}</p>
              )}
              {invoice.paymentInfo.paypalEmail && (
                <p>PayPal: {invoice.paymentInfo.paypalEmail}</p>
              )}
              {invoice.paymentInfo.wiseEmail && (
                <p>Wise: {invoice.paymentInfo.wiseEmail}</p>
              )}
              {invoice.paymentInfo.paymentLink && (
                <p>Payment Link: <a href={invoice.paymentInfo.paymentLink} className="text-primary underline">{invoice.paymentInfo.paymentLink}</a></p>
              )}
            </div>
          </div>
        )}

        {/* Notes & Terms */}
        {(invoice.notes || invoice.terms || invoice.invoiceNotes?.thankYouMessage) && (
          <div className="border-t border-border pt-6 space-y-4 text-sm">
            {invoice.notes && (
              <div>
                <h4 className="font-semibold text-foreground mb-1">Notes</h4>
                <p className="text-muted-foreground whitespace-pre-line">{invoice.notes}</p>
              </div>
            )}
            {invoice.terms && (
              <div>
                <h4 className="font-semibold text-foreground mb-1">Terms & Conditions</h4>
                <p className="text-muted-foreground whitespace-pre-line">{invoice.terms}</p>
              </div>
            )}
            {invoice.invoiceNotes?.thankYouMessage && (
              <p className="text-center text-muted-foreground italic pt-2">
                {invoice.invoiceNotes.thankYouMessage}
              </p>
            )}
          </div>
        )}

        {/* Signature */}
        {(invoice.signature?.authorizedSignatory || invoice.signature?.designation) && (
          <div className="mt-8 pt-6 border-t border-border">
            <div className="flex justify-end">
              <div className="text-right">
                {/* Auto-generated cursive signature */}
                {invoice.signature.authorizedSignatory && (
                  <p className="font-signature text-3xl text-foreground mb-2 min-h-[48px]">
                    {invoice.signature.authorizedSignatory}
                  </p>
                )}
                <div className="border-t border-foreground pt-2 min-w-[200px]">
                  {invoice.signature.authorizedSignatory && (
                    <p className="font-semibold text-foreground">{invoice.signature.authorizedSignatory}</p>
                  )}
                  {invoice.signature.designation && (
                    <p className="text-sm text-muted-foreground">{invoice.signature.designation}</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
        </div>
      </div>
    );
  }
);

InvoicePreview.displayName = 'InvoicePreview';
