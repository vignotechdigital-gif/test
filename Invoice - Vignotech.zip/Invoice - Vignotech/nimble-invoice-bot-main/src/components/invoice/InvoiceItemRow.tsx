import { Trash2, Percent, DollarSign, List, ListOrdered } from 'lucide-react';
import { InvoiceItem, DiscountType } from '@/types/invoice';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { useEffect, useRef, useState } from 'react';

interface InvoiceItemRowProps {
  item: InvoiceItem;
  index: number;
  onChange: (item: InvoiceItem) => void;
  onDelete: () => void;
  canDelete: boolean;
}

export function InvoiceItemRow({ item, index, onChange, onDelete, canDelete }: InvoiceItemRowProps) {
  const descriptionRef = useRef<HTMLTextAreaElement>(null);

  // Keep numeric inputs as strings while typing so the value doesn't snap to 0
  // when the user clears the field or types partial values.
  const [quantityInput, setQuantityInput] = useState<string>(String(item.quantity ?? 0));
  const [rateInput, setRateInput] = useState<string>(String(item.rate ?? 0));
  const [discountValueInput, setDiscountValueInput] = useState<string>(String(item.discountValue ?? 0));

  useEffect(() => {
    setQuantityInput(String(item.quantity ?? 0));
  }, [item.quantity]);

  useEffect(() => {
    setRateInput(String(item.rate ?? 0));
  }, [item.rate]);

  useEffect(() => {
    setDiscountValueInput(String(item.discountValue ?? 0));
  }, [item.discountValue]);

  const calculateAmount = (
    quantity: number,
    rate: number,
    discountType: DiscountType,
    discountValue: number
  ) => {
    const subtotal = quantity * rate;
    let discountAmount = 0;
    
    if (discountType === 'percentage') {
      discountAmount = (subtotal * discountValue) / 100;
    } else {
      discountAmount = discountValue;
    }
    
    return {
      discountAmount: Math.min(discountAmount, subtotal),
      amount: Math.max(0, subtotal - discountAmount),
    };
  };

  const handleChange = (field: keyof InvoiceItem, value: string | number) => {
    const updatedItem = { ...item, [field]: value };
    
    if (field === 'quantity' || field === 'rate' || field === 'discountValue' || field === 'discountType') {
      const quantity = field === 'quantity' ? Number(value) : item.quantity;
      const rate = field === 'rate' ? Number(value) : item.rate;
      const discountType = field === 'discountType' ? (value as DiscountType) : item.discountType;
      const discountValue = field === 'discountValue' ? Number(value) : item.discountValue;
      
      const { discountAmount, amount } = calculateAmount(quantity, rate, discountType, discountValue);
      updatedItem.discountAmount = discountAmount;
      updatedItem.amount = amount;
    }
    
    onChange(updatedItem);
  };

  const insertBullet = () => {
    const textarea = descriptionRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = item.description;
    
    // Get the current line
    const beforeCursor = text.substring(0, start);
    const afterCursor = text.substring(end);
    const lastNewline = beforeCursor.lastIndexOf('\n');
    const lineStart = lastNewline + 1;
    const currentLineBeforeCursor = beforeCursor.substring(lineStart);
    
    // Check if we're at the start of a line or need a newline
    let newText: string;
    let newCursorPos: number;
    
    if (start === 0 || beforeCursor.endsWith('\n')) {
      // At start of line, just add bullet
      newText = beforeCursor + '• ' + afterCursor;
      newCursorPos = start + 2;
    } else if (currentLineBeforeCursor.trim() === '') {
      // Line has only whitespace, replace with bullet
      newText = text.substring(0, lineStart) + '• ' + afterCursor;
      newCursorPos = lineStart + 2;
    } else {
      // In middle of text, add newline then bullet
      newText = beforeCursor + '\n• ' + afterCursor;
      newCursorPos = start + 3;
    }
    
    handleChange('description', newText);
    
    // Set cursor position after state update
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  };

  const insertNumbering = () => {
    const textarea = descriptionRef.current;
    if (!textarea) return;

    const text = item.description;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const beforeCursor = text.substring(0, start);
    const afterCursor = text.substring(end);
    
    // Count existing numbered items to determine next number
    const lines = text.split('\n');
    const numberedLineRegex = /^\d+\.\s/;
    let nextNumber = 1;
    
    // Find the highest number in existing numbered lines
    lines.forEach(line => {
      const match = line.match(/^(\d+)\.\s/);
      if (match) {
        const num = parseInt(match[1], 10);
        if (num >= nextNumber) {
          nextNumber = num + 1;
        }
      }
    });
    
    const lastNewline = beforeCursor.lastIndexOf('\n');
    const lineStart = lastNewline + 1;
    const currentLineBeforeCursor = beforeCursor.substring(lineStart);
    
    let newText: string;
    let newCursorPos: number;
    const numberPrefix = `${nextNumber}. `;
    
    if (start === 0 || beforeCursor.endsWith('\n')) {
      newText = beforeCursor + numberPrefix + afterCursor;
      newCursorPos = start + numberPrefix.length;
    } else if (currentLineBeforeCursor.trim() === '') {
      newText = text.substring(0, lineStart) + numberPrefix + afterCursor;
      newCursorPos = lineStart + numberPrefix.length;
    } else {
      newText = beforeCursor + '\n' + numberPrefix + afterCursor;
      newCursorPos = start + 1 + numberPrefix.length;
    }
    
    handleChange('description', newText);
    
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  };

  const lineSubtotal = item.quantity * item.rate;

  return (
    <tr className="animate-fade-in">
      {/* # */}
      <td className="border border-border p-3 text-center text-muted-foreground text-sm bg-muted/30 align-top">
        {index + 1}
      </td>
      
      {/* Title & Description */}
      <td className="border border-border p-3 min-w-[380px]">
        <Input
          value={item.title}
          onChange={(e) => handleChange('title', e.target.value)}
          placeholder="Item title"
          className="font-medium mb-2 border-dashed"
        />
        <div className="relative">
          <div className="flex gap-1 mb-1">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={insertBullet}
              className="h-7 px-2 text-xs"
              title="Add bullet point"
            >
              <List className="h-3 w-3 mr-1" />
              Bullet
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={insertNumbering}
              className="h-7 px-2 text-xs"
              title="Add numbered item"
            >
              <ListOrdered className="h-3 w-3 mr-1" />
              Number
            </Button>
          </div>
          <Textarea
            ref={descriptionRef}
            value={item.description}
            onChange={(e) => handleChange('description', e.target.value)}
            placeholder="Description (optional) - use buttons above for bullets/numbers"
            className="text-sm border-dashed min-h-[60px] resize-y font-mono"
            rows={2}
          />
        </div>
      </td>
      
      {/* Qty */}
      <td className="border border-border p-3 align-top">
        <Input
          type="number"
          value={quantityInput}
          onChange={(e) => {
            const next = e.target.value;
            setQuantityInput(next);
            if (next === '') return;
            const parsed = Number(next);
            if (!Number.isNaN(parsed)) {
              handleChange('quantity', parsed);
            }
          }}
          onBlur={() => {
            if (quantityInput.trim() === '') {
              setQuantityInput('0');
              handleChange('quantity', 0);
            }
          }}
          min="0"
          step="1"
          className="text-center border-dashed"
        />
      </td>
      
      {/* Rate */}
      <td className="border border-border p-3 align-top">
        <Input
          type="number"
          value={rateInput}
          onChange={(e) => {
            const next = e.target.value;
            setRateInput(next);
            if (next === '') return;
            const parsed = Number(next);
            if (!Number.isNaN(parsed)) {
              handleChange('rate', parsed);
            }
          }}
          onBlur={() => {
            if (rateInput.trim() === '') {
              setRateInput('0');
              handleChange('rate', 0);
            }
          }}
          min="0"
          step="0.01"
          className="text-right border-dashed"
        />
      </td>
      
      {/* Discount */}
      <td className="border border-border p-3 align-top">
        <div className="flex gap-1">
          <div className="flex rounded-md border border-input overflow-hidden shrink-0">
            <button
              type="button"
              onClick={() => handleChange('discountType', 'percentage')}
              className={cn(
                "px-2 py-2 transition-colors",
                item.discountType === 'percentage' 
                  ? "bg-primary text-primary-foreground" 
                  : "bg-background text-muted-foreground hover:bg-muted"
              )}
            >
              <Percent className="h-3 w-3" />
            </button>
            <button
              type="button"
              onClick={() => handleChange('discountType', 'fixed')}
              className={cn(
                "px-2 py-2 transition-colors",
                item.discountType === 'fixed' 
                  ? "bg-primary text-primary-foreground" 
                  : "bg-background text-muted-foreground hover:bg-muted"
              )}
            >
              <DollarSign className="h-3 w-3" />
            </button>
          </div>
          <Input
            type="number"
            value={discountValueInput}
            onChange={(e) => {
              const next = e.target.value;
              setDiscountValueInput(next);
              if (next === '') return;
              const parsed = Number(next);
              if (!Number.isNaN(parsed)) {
                handleChange('discountValue', parsed);
              }
            }}
            onBlur={() => {
              if (discountValueInput.trim() === '') {
                setDiscountValueInput('0');
                handleChange('discountValue', 0);
              }
            }}
            placeholder="0"
            min="0"
            step={item.discountType === 'percentage' ? '1' : '0.01'}
            max={item.discountType === 'percentage' ? '100' : undefined}
            className="text-right flex-1 min-w-[60px] border-dashed"
          />
        </div>
      </td>
      
      {/* Amount */}
      <td className="border border-border p-3 bg-muted/30 align-top">
        <div className="flex flex-col items-end">
          {item.discountAmount > 0 && (
            <span className="text-xs text-muted-foreground line-through">
              ${lineSubtotal.toFixed(2)}
            </span>
          )}
          <span className="font-semibold text-foreground text-base">
            ${item.amount.toFixed(2)}
          </span>
        </div>
      </td>
      
      {/* Actions */}
      <td className="border border-border p-3 text-center align-top">
        <Button
          type="button"
          variant="ghost"
          size="icon"
          onClick={onDelete}
          disabled={!canDelete}
          className="h-8 w-8 text-muted-foreground hover:text-destructive disabled:opacity-30"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </td>
    </tr>
  );
}
