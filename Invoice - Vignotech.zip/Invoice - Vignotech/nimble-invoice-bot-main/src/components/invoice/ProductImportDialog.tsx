import { Package, Check, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { useProducts } from '@/hooks/useProducts';
import { useState } from 'react';
import { InvoiceItem } from '@/types/invoice';

interface ProductImportDialogProps {
  onImport: (items: Omit<InvoiceItem, 'id'>[]) => void;
}

export function ProductImportDialog({ onImport }: ProductImportDialogProps) {
  const { products, isLoading } = useProducts();
  const [selectedProducts, setSelectedProducts] = useState<Set<string>>(new Set());
  const [open, setOpen] = useState(false);

  const toggleProduct = (productId: string) => {
    const newSelected = new Set(selectedProducts);
    if (newSelected.has(productId)) {
      newSelected.delete(productId);
    } else {
      newSelected.add(productId);
    }
    setSelectedProducts(newSelected);
  };

  const selectAll = () => {
    setSelectedProducts(new Set(products.map(p => p.id)));
  };

  const clearSelection = () => {
    setSelectedProducts(new Set());
  };

  const handleImport = () => {
    const items = products
      .filter(p => selectedProducts.has(p.id))
      .map(product => ({
        title: product.title,
        description: product.description,
        quantity: product.default_quantity || 1,
        rate: product.default_rate || 0,
        discountType: 'percentage' as const,
        discountValue: 0,
        discountAmount: 0,
        amount: 0,
      }));
    onImport(items);
    setSelectedProducts(new Set());
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button type="button" variant="outline" className="gap-2">
          <Package className="h-4 w-4" />
          Import Product
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>Import Products</DialogTitle>
        </DialogHeader>
        
        <div className="flex-1 overflow-y-auto space-y-3 py-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No products found in database
            </div>
          ) : (
            products.map((product) => {
              const isSelected = selectedProducts.has(product.id);
              return (
                <button
                  key={product.id}
                  type="button"
                  onClick={() => toggleProduct(product.id)}
                  className={`w-full text-left p-4 rounded-lg border transition-all ${
                    isSelected 
                      ? 'border-primary bg-primary/5 ring-2 ring-primary/20' 
                      : 'border-border bg-card hover:border-primary/50'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-5 h-5 rounded border-2 flex items-center justify-center shrink-0 mt-0.5 transition-colors ${
                      isSelected ? 'border-primary bg-primary' : 'border-muted-foreground'
                    }`}>
                      {isSelected && <Check className="h-3 w-3 text-primary-foreground" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-foreground mb-1">{product.title}</h4>
                      <p className="text-sm text-muted-foreground line-clamp-2">{product.description}</p>
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-border">
          <p className="text-sm text-muted-foreground">
            {selectedProducts.size} product{selectedProducts.size !== 1 ? 's' : ''} selected
          </p>
          <div className="flex gap-2">
            {products.length > 0 && (
              <>
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="sm"
                  onClick={selectedProducts.size === products.length ? clearSelection : selectAll}
                >
                  {selectedProducts.size === products.length ? 'Clear All' : 'Select All'}
                </Button>
              </>
            )}
          </div>
          <div className="flex gap-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button 
              type="button" 
              variant="gradient" 
              onClick={handleImport}
              disabled={selectedProducts.size === 0}
            >
              Import {selectedProducts.size === products.length ? 'All' : 'Selected'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
