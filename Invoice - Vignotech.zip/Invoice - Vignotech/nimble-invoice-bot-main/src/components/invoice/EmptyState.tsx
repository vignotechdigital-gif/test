import { FileText, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

export function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 animate-fade-in">
      <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mb-6">
        <FileText className="w-10 h-10 text-muted-foreground" />
      </div>
      <h3 className="text-xl font-semibold text-foreground mb-2">No invoices yet</h3>
      <p className="text-muted-foreground text-center max-w-sm mb-6">
        Create your first invoice to get started. It only takes a few minutes.
      </p>
      <Button asChild variant="gradient" size="lg">
        <Link to="/create">
          <Plus className="h-4 w-4" />
          Create Invoice
        </Link>
      </Button>
    </div>
  );
}
