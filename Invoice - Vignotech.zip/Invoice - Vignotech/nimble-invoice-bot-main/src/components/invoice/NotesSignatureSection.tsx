import { InvoiceNotes, SignatureInfo } from '@/types/invoice';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

interface NotesSignatureSectionProps {
  notes: string;
  terms: string;
  invoiceNotes: InvoiceNotes;
  signature: SignatureInfo;
  onNotesChange: (notes: string) => void;
  onTermsChange: (terms: string) => void;
  onInvoiceNotesChange: (invoiceNotes: InvoiceNotes) => void;
  onSignatureChange: (signature: SignatureInfo) => void;
}

export function NotesSignatureSection({
  notes,
  terms,
  invoiceNotes,
  signature,
  onNotesChange,
  onTermsChange,
  onInvoiceNotesChange,
  onSignatureChange,
}: NotesSignatureSectionProps) {
  const updateInvoiceNotes = <K extends keyof InvoiceNotes>(field: K, value: InvoiceNotes[K]) => {
    onInvoiceNotesChange({ ...invoiceNotes, [field]: value });
  };

  const updateSignature = <K extends keyof SignatureInfo>(field: K, value: SignatureInfo[K]) => {
    onSignatureChange({ ...signature, [field]: value });
  };

  return (
    <div className="rounded-lg border border-border bg-card p-4 shadow-card animate-fade-in">
      <h2 className="text-base font-semibold text-foreground mb-3">Notes, Terms & Signature</h2>
      
      <div className="space-y-6">
        {/* Client-Facing Notes */}
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="clientNotes">Notes for Client</Label>
            <Textarea
              id="clientNotes"
              value={notes}
              onChange={(e) => onNotesChange(e.target.value)}
              placeholder="Additional notes visible to the client..."
              className="mt-1"
              rows={3}
            />
          </div>
          <div>
            <Label htmlFor="terms">Terms & Conditions</Label>
            <Textarea
              id="terms"
              value={terms}
              onChange={(e) => onTermsChange(e.target.value)}
              placeholder="Payment terms and conditions..."
              className="mt-1"
              rows={3}
            />
          </div>
        </div>

        {/* Thank You Message */}
        <div>
          <Label htmlFor="thankYouMessage">Thank You Message</Label>
          <Input
            id="thankYouMessage"
            value={invoiceNotes.thankYouMessage || ''}
            onChange={(e) => updateInvoiceNotes('thankYouMessage', e.target.value)}
            placeholder="Thank you for your business!"
            className="mt-1"
          />
        </div>

        {/* Internal Notes */}
        <div className="p-4 bg-muted/30 rounded-lg border border-border">
          <Label htmlFor="internalNotes" className="flex items-center gap-2">
            Internal Notes 
            <span className="text-xs text-muted-foreground font-normal">(Not shown on invoice)</span>
          </Label>
          <Textarea
            id="internalNotes"
            value={invoiceNotes.internalNotes || ''}
            onChange={(e) => updateInvoiceNotes('internalNotes', e.target.value)}
            placeholder="Private notes for internal reference only..."
            className="mt-1 bg-background"
            rows={2}
          />
        </div>

        {/* Signature */}
        <div className="border-t border-border pt-4">
          <h3 className="text-sm font-semibold text-foreground mb-3">Authorized Signature</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="signatory">Signatory Name</Label>
              <Input
                id="signatory"
                value={signature.authorizedSignatory || ''}
                onChange={(e) => updateSignature('authorizedSignatory', e.target.value)}
                placeholder="Full Name"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="designation">Designation</Label>
              <Input
                id="designation"
                value={signature.designation || ''}
                onChange={(e) => updateSignature('designation', e.target.value)}
                placeholder="e.g., Director, Manager"
                className="mt-1"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
