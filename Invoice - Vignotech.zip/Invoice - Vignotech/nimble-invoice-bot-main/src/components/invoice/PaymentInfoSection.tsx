import { PaymentInfo } from '@/types/invoice';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useState } from 'react';

interface PaymentInfoSectionProps {
  paymentInfo: PaymentInfo;
  onChange: (paymentInfo: PaymentInfo) => void;
}

const PAYMENT_METHOD_OPTIONS = [
  'Bank Transfer',
  'PayPal',
  'Wise',
  'UPI',
  'Cheque',
  'Cash',
];

export function PaymentInfoSection({ paymentInfo, onChange }: PaymentInfoSectionProps) {
  const [showBankDetails, setShowBankDetails] = useState(
    paymentInfo.paymentMethods.includes('Bank Transfer')
  );

  const togglePaymentMethod = (method: string, checked: boolean) => {
    const updatedMethods = checked
      ? [...paymentInfo.paymentMethods, method]
      : paymentInfo.paymentMethods.filter((m) => m !== method);
    
    if (method === 'Bank Transfer') {
      setShowBankDetails(checked);
    }
    
    onChange({ ...paymentInfo, paymentMethods: updatedMethods });
  };

  const updateField = <K extends keyof PaymentInfo>(field: K, value: PaymentInfo[K]) => {
    onChange({ ...paymentInfo, [field]: value });
  };

  const updateBankDetail = (field: string, value: string) => {
    onChange({
      ...paymentInfo,
      bankDetails: {
        ...paymentInfo.bankDetails,
        [field]: value,
      },
    });
  };

  return (
    <div className="rounded-lg border border-border bg-card p-4 shadow-card animate-fade-in">
      <h2 className="text-base font-semibold text-foreground mb-3">Payment Information</h2>
      
      {/* Payment Methods */}
      <div className="mb-6">
        <Label className="mb-3 block">Accepted Payment Methods</Label>
        <div className="flex flex-wrap gap-4">
          {PAYMENT_METHOD_OPTIONS.map((method) => (
            <div key={method} className="flex items-center space-x-2">
              <Checkbox
                id={`method-${method}`}
                checked={paymentInfo.paymentMethods.includes(method)}
                onCheckedChange={(checked) => togglePaymentMethod(method, checked as boolean)}
              />
              <label
                htmlFor={`method-${method}`}
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
              >
                {method}
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Bank Details */}
      {showBankDetails && (
        <div className="mb-6 p-4 bg-muted/30 rounded-lg border border-border">
          <h3 className="text-sm font-semibold text-foreground mb-3">Bank Details</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="bankName">Bank Name</Label>
              <Input
                id="bankName"
                value={paymentInfo.bankDetails?.bankName || ''}
                onChange={(e) => updateBankDetail('bankName', e.target.value)}
                placeholder="Bank Name"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="accountName">Account Name</Label>
              <Input
                id="accountName"
                value={paymentInfo.bankDetails?.accountName || ''}
                onChange={(e) => updateBankDetail('accountName', e.target.value)}
                placeholder="Account Holder Name"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="accountNumber">Account Number</Label>
              <Input
                id="accountNumber"
                value={paymentInfo.bankDetails?.accountNumber || ''}
                onChange={(e) => updateBankDetail('accountNumber', e.target.value)}
                placeholder="Account Number"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="branch">Branch</Label>
              <Input
                id="branch"
                value={paymentInfo.bankDetails?.branch || ''}
                onChange={(e) => updateBankDetail('branch', e.target.value)}
                placeholder="Branch Name"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="ifscCode">IFSC Code (India)</Label>
              <Input
                id="ifscCode"
                value={paymentInfo.bankDetails?.ifscCode || ''}
                onChange={(e) => updateBankDetail('ifscCode', e.target.value.toUpperCase())}
                placeholder="IFSC Code"
                className="mt-1 uppercase"
              />
            </div>
            <div>
              <Label htmlFor="swiftCode">SWIFT Code (International)</Label>
              <Input
                id="swiftCode"
                value={paymentInfo.bankDetails?.swiftCode || ''}
                onChange={(e) => updateBankDetail('swiftCode', e.target.value.toUpperCase())}
                placeholder="SWIFT/BIC Code"
                className="mt-1 uppercase"
              />
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="iban">IBAN (Europe)</Label>
              <Input
                id="iban"
                value={paymentInfo.bankDetails?.iban || ''}
                onChange={(e) => updateBankDetail('iban', e.target.value.toUpperCase())}
                placeholder="International Bank Account Number"
                className="mt-1 uppercase"
              />
            </div>
          </div>
        </div>
      )}

      {/* Other Payment Details */}
      <div className="grid sm:grid-cols-2 gap-4">
        {paymentInfo.paymentMethods.includes('PayPal') && (
          <div>
            <Label htmlFor="paypalEmail">PayPal Email</Label>
            <Input
              id="paypalEmail"
              type="email"
              value={paymentInfo.paypalEmail || ''}
              onChange={(e) => updateField('paypalEmail', e.target.value)}
              placeholder="paypal@example.com"
              className="mt-1"
            />
          </div>
        )}
        {paymentInfo.paymentMethods.includes('Wise') && (
          <div>
            <Label htmlFor="wiseEmail">Wise Email</Label>
            <Input
              id="wiseEmail"
              type="email"
              value={paymentInfo.wiseEmail || ''}
              onChange={(e) => updateField('wiseEmail', e.target.value)}
              placeholder="wise@example.com"
              className="mt-1"
            />
          </div>
        )}
        {paymentInfo.paymentMethods.includes('UPI') && (
          <div>
            <Label htmlFor="upiId">UPI ID</Label>
            <Input
              id="upiId"
              value={paymentInfo.upiId || ''}
              onChange={(e) => updateField('upiId', e.target.value)}
              placeholder="yourname@upi"
              className="mt-1"
            />
          </div>
        )}
        <div className={paymentInfo.paymentMethods.length > 0 ? '' : 'sm:col-span-2'}>
          <Label htmlFor="paymentLink">Payment Link (Optional)</Label>
          <Input
            id="paymentLink"
            type="url"
            value={paymentInfo.paymentLink || ''}
            onChange={(e) => updateField('paymentLink', e.target.value)}
            placeholder="https://pay.example.com/invoice/123"
            className="mt-1"
          />
        </div>
      </div>
    </div>
  );
}
