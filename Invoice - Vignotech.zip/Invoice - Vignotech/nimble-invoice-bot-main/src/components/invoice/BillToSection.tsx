import { ClientInfo } from '@/types/invoice';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ClientSearchSelect } from '@/components/clients/ClientSearchSelect';
import { useClients } from '@/hooks/useClients';
import { Client } from '@/services/clientService';

interface BillToSectionProps {
  client: ClientInfo;
  onChange: (client: ClientInfo) => void;
}

export function BillToSection({ client, onChange }: BillToSectionProps) {
  const { clients, isLoading } = useClients();

  const updateField = <K extends keyof ClientInfo>(field: K, value: ClientInfo[K]) => {
    onChange({ ...client, [field]: value });
  };

  const handleClientSelect = (selectedClient: Client | null) => {
    if (selectedClient) {
      onChange({
        name: selectedClient.name || '',
        companyName: selectedClient.companyName || '',
        email: selectedClient.email || '',
        phone: selectedClient.phone || '',
        addressLine1: selectedClient.addressLine1 || '',
        addressLine2: selectedClient.addressLine2 || '',
        city: selectedClient.city || '',
        stateProvince: selectedClient.stateProvince || '',
        postalCode: selectedClient.postalCode || '',
        country: selectedClient.country || '',
        countryCode: selectedClient.countryCode || '',
        taxId: selectedClient.taxId || '',
      });
    }
  };

  // Find selected client ID by matching email
  const selectedClientId = clients.find(c => c.email === client.email && client.email)?.id ?? null;

  return (
    <div className="rounded-lg border border-border bg-card p-4 shadow-card animate-fade-in">
      <h2 className="text-base font-semibold text-foreground mb-3">Bill To (Client)</h2>
      
      {/* Client Search */}
      <div className="mb-4">
        <Label className="mb-1.5 block text-sm">Select Existing Client</Label>
        <ClientSearchSelect
          clients={clients}
          value={selectedClientId}
          onChange={handleClientSelect}
          placeholder={isLoading ? 'Loading clients...' : 'Search clients...'}
          disabled={isLoading}
        />
        <p className="mt-1 text-xs text-muted-foreground">
          Or enter client details manually below
        </p>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="clientName">Client Name *</Label>
          <Input
            id="clientName"
            value={client.name}
            onChange={(e) => updateField('name', e.target.value)}
            placeholder="Contact Person Name"
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="companyName">Company Name</Label>
          <Input
            id="companyName"
            value={client.companyName || ''}
            onChange={(e) => updateField('companyName', e.target.value)}
            placeholder="Client Company Name"
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="clientEmail">Email</Label>
          <Input
            id="clientEmail"
            type="email"
            value={client.email}
            onChange={(e) => updateField('email', e.target.value)}
            placeholder="client@example.com"
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="clientPhone">Phone</Label>
          <Input
            id="clientPhone"
            value={client.phone || ''}
            onChange={(e) => updateField('phone', e.target.value)}
            placeholder="+1 234 567 890"
            className="mt-1"
          />
        </div>
        <div className="sm:col-span-2">
          <Label htmlFor="addressLine1">Address Line 1</Label>
          <Input
            id="addressLine1"
            value={client.addressLine1}
            onChange={(e) => updateField('addressLine1', e.target.value)}
            placeholder="Street address, P.O. box"
            className="mt-1"
          />
        </div>
        <div className="sm:col-span-2">
          <Label htmlFor="addressLine2">Address Line 2</Label>
          <Input
            id="addressLine2"
            value={client.addressLine2 || ''}
            onChange={(e) => updateField('addressLine2', e.target.value)}
            placeholder="Apartment, suite, unit, building, floor, etc."
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="clientCity">City</Label>
          <Input
            id="clientCity"
            value={client.city}
            onChange={(e) => updateField('city', e.target.value)}
            placeholder="City"
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="stateProvince">State / Province</Label>
          <Input
            id="stateProvince"
            value={client.stateProvince || ''}
            onChange={(e) => updateField('stateProvince', e.target.value)}
            placeholder="State or Province"
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="postalCode">Postal Code</Label>
          <Input
            id="postalCode"
            value={client.postalCode || ''}
            onChange={(e) => updateField('postalCode', e.target.value)}
            placeholder="ZIP / Postal Code"
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="clientCountry">Country</Label>
          <Input
            id="clientCountry"
            value={client.country}
            onChange={(e) => updateField('country', e.target.value)}
            placeholder="Country"
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="countryCode">Country Code</Label>
          <Input
            id="countryCode"
            value={client.countryCode || ''}
            onChange={(e) => updateField('countryCode', e.target.value.toUpperCase())}
            placeholder="IN, US, CA, GB..."
            maxLength={3}
            className="mt-1 uppercase"
          />
        </div>
        <div>
          <Label htmlFor="taxId">Tax ID / VAT / GST</Label>
          <Input
            id="taxId"
            value={client.taxId || ''}
            onChange={(e) => updateField('taxId', e.target.value)}
            placeholder="Client's tax identification number"
            className="mt-1"
          />
        </div>
      </div>
    </div>
  );
}
