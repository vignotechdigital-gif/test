import { format } from 'date-fns';
import { MoreVertical, Eye, Trash2, Download, Edit2 } from 'lucide-react';
import { Invoice } from '@/types/invoice';
import { StatusBadge } from './StatusBadge';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Link } from 'react-router-dom';

interface InvoiceCardProps {
  invoice: Invoice;
  onDelete: (id: string) => void;
}

export function InvoiceCard({ invoice, onDelete }: InvoiceCardProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatDate = (dateStr: string | undefined) => {
    if (!dateStr) return 'N/A';
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return 'N/A';
    return format(date, 'MMM d, yyyy');
  };

  return (
    <div className="group relative rounded-xl border border-border bg-card p-5 shadow-card transition-all duration-200 hover:shadow-card-hover hover:border-primary/20 animate-fade-in">
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <h3 className="font-semibold text-foreground">{invoice.invoiceNumber}</h3>
            <StatusBadge status={invoice.status} />
          </div>
          <p className="text-sm text-muted-foreground">{invoice.client.name}</p>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity">
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-popover border border-border shadow-lg z-50">
            <DropdownMenuItem asChild>
              <Link to={`/invoice/${invoice.id}`} className="flex items-center gap-2 cursor-pointer">
                <Eye className="h-4 w-4" />
                View
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link to={`/create?edit=${invoice.id}`} className="flex items-center gap-2 cursor-pointer">
                <Edit2 className="h-4 w-4" />
                Edit
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link to={`/invoice/${invoice.id}?download=true`} className="flex items-center gap-2 cursor-pointer">
                <Download className="h-4 w-4" />
                Download
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => onDelete(invoice.id)}
              className="flex items-center gap-2 text-destructive cursor-pointer"
            >
              <Trash2 className="h-4 w-4" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="mt-4 flex items-end justify-between">
        <div className="space-y-1 text-sm text-muted-foreground">
          <p>Issued: {formatDate(invoice.date)}</p>
          <p>Due: {formatDate(invoice.dueDate)}</p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-foreground">{formatCurrency(invoice.total)}</p>
        </div>
      </div>
    </div>
  );
}
