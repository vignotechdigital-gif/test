import { useState, useMemo } from 'react';
import { Check, ChevronsUpDown, Search, UserPlus } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Client } from '@/services/clientService';

interface ClientSearchSelectProps {
  clients: Client[];
  value?: number | null;
  onChange: (client: Client | null) => void;
  placeholder?: string;
  disabled?: boolean;
}

export function ClientSearchSelect({
  clients,
  value,
  onChange,
  placeholder = 'Search clients...',
  disabled,
}: ClientSearchSelectProps) {
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const selectedClient = useMemo(() => {
    return clients.find((c) => c.id === value) || null;
  }, [clients, value]);

  const filteredClients = useMemo(() => {
    if (!searchQuery) return clients;
    const query = searchQuery.toLowerCase();
    return clients.filter(
      (client) =>
        client.name?.toLowerCase().includes(query) ||
        client.companyName?.toLowerCase().includes(query) ||
        client.email?.toLowerCase().includes(query) ||
        client.phone?.includes(query)
    );
  }, [clients, searchQuery]);

  const handleSelect = (clientId: string) => {
    if (clientId === 'clear') {
      onChange(null);
    } else {
      const client = clients.find((c) => c.id.toString() === clientId);
      onChange(client || null);
    }
    setOpen(false);
    setSearchQuery('');
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className={cn(
            'w-full justify-between font-normal',
            !selectedClient && 'text-muted-foreground'
          )}
          disabled={disabled}
        >
          <div className="flex items-center gap-2 truncate">
            <Search className="h-4 w-4 shrink-0 opacity-50" />
            {selectedClient ? (
              <span className="truncate">
                {selectedClient.name}
                {selectedClient.companyName && ` (${selectedClient.companyName})`}
              </span>
            ) : (
              placeholder
            )}
          </div>
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[400px] p-0" align="start">
        <Command shouldFilter={false}>
          <CommandInput
            placeholder="Search by name, company, email..."
            value={searchQuery}
            onValueChange={setSearchQuery}
          />
          <CommandList>
            <CommandEmpty>
              <div className="flex flex-col items-center gap-2 py-4">
                <UserPlus className="h-8 w-8 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">No clients found</p>
                <p className="text-xs text-muted-foreground">
                  Add clients in the Clients section first
                </p>
              </div>
            </CommandEmpty>
            <CommandGroup>
              {selectedClient && (
                <CommandItem
                  value="clear"
                  onSelect={handleSelect}
                  className="text-muted-foreground"
                >
                  <span className="text-sm">Clear selection</span>
                </CommandItem>
              )}
              {filteredClients.map((client) => (
                <CommandItem
                  key={client.id}
                  value={client.id.toString()}
                  onSelect={handleSelect}
                  className="flex flex-col items-start gap-1 py-3"
                >
                  <div className="flex w-full items-center">
                    <Check
                      className={cn(
                        'mr-2 h-4 w-4',
                        value === client.id ? 'opacity-100' : 'opacity-0'
                      )}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium truncate">{client.name}</span>
                        {client.companyName && (
                          <span className="text-xs text-muted-foreground truncate">
                            ({client.companyName})
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        {client.email && <span className="truncate">{client.email}</span>}
                        {client.phone && <span>{client.phone}</span>}
                      </div>
                    </div>
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
