import { InvoiceItem } from '@/types/invoice';

export interface Product {
  id: string;
  title: string;
  description: string;
  defaultRate?: number;
  defaultQuantity?: number;
}

export const PRODUCTS: Product[] = [
  {
    id: 'domain-3yr',
    title: 'Domain - 3 years validity',
    description: '• Domain ending with .com as per client\'s requirement',
    defaultRate: 0,
    defaultQuantity: 1,
  },
  {
    id: 'hosting-3yr',
    title: 'Hosting - 3 years',
    description: `• Unlimited Disk NVMe
• Unlimited Bandwidth + Emails
• Unlimited Sites + FTP
• Powerful cPanel
• Unlimited Websites
• 1,50,000 Monthly Visitors
• Lifetime Free SSL
• Support 24x7x365
• DNS Management
• 1-click WordPress install
• Unlimited FTP Accounts
• Mail Channel Email Filters
• Application Firewall
• Free Website Migration
• WordPress Support
• Vulnerabilities scanner
• PHP MyAdmin
• Multiple PHP Version
• 99.9% Uptime Guarantee`,
    defaultRate: 0,
    defaultQuantity: 1,
  },
  {
    id: 'web-dev',
    title: 'Web Development - Web Development Package',
    description: `Design, development, and deployment of business website.

Includes:
• Custom Web Design
• Contact Form integration
• SEO Setup (Meta tags & Sitemap)
• Mobile/Tablet optimization`,
    defaultRate: 0,
    defaultQuantity: 1,
  },
  {
    id: 'prod-support-3yr',
    title: 'Production Support - 3 Years',
    description: `• Resolution of break/fix tickets and critical errors
• Routine server maintenance and security hardening
• Development of new features as per Client's requests
• Content updates and frontend visual improvements
• Speed and database optimization`,
    defaultRate: 0,
    defaultQuantity: 1,
  },
  {
    id: 'ssl-premium',
    title: 'SSL Certificate - Premium',
    description: '• Extended Validation SSL for enhanced security\n• Green address bar with company name\n• Highest level of trust indicator',
    defaultRate: 0,
    defaultQuantity: 1,
  },
  {
    id: 'email-hosting',
    title: 'Email Hosting',
    description: '• Professional email with custom domain\n• Webmail access + IMAP/POP3\n• Spam & virus protection\n• 10GB mailbox storage',
    defaultRate: 0,
    defaultQuantity: 1,
  },
  {
    id: 'cdn-integration',
    title: 'CDN Integration',
    description: '• Cloudflare/AWS CDN for faster global loading\n• DDoS protection included\n• Edge caching for static assets',
    defaultRate: 0,
    defaultQuantity: 1,
  },
  {
    id: 'backup-service',
    title: 'Backup Service',
    description: '• Daily automated backups with 30-day retention\n• One-click restore functionality\n• Off-site secure storage',
    defaultRate: 0,
    defaultQuantity: 1,
  },
  {
    id: 'security-monitoring',
    title: 'Security Monitoring',
    description: '• 24/7 malware scanning and firewall monitoring\n• Real-time threat detection\n• Automatic malware removal',
    defaultRate: 0,
    defaultQuantity: 1,
  },
  {
    id: 'google-workspace',
    title: 'Google Workspace Setup',
    description: '• Business email + Drive + Calendar setup\n• User account configuration\n• DNS records configuration\n• Admin console training',
    defaultRate: 0,
    defaultQuantity: 1,
  },
  {
    id: 'logo-design',
    title: 'Logo Design',
    description: '• Professional logo with multiple formats\n• 3 initial concepts\n• Unlimited revisions\n• Source files included (AI, EPS, PNG, SVG)',
    defaultRate: 0,
    defaultQuantity: 1,
  },
  {
    id: 'content-writing',
    title: 'Content Writing',
    description: '• SEO-optimized website copy\n• Keyword research included\n• Meta descriptions for all pages\n• Up to 10 pages',
    defaultRate: 0,
    defaultQuantity: 1,
  },
  {
    id: 'ecommerce-integration',
    title: 'E-commerce Integration',
    description: '• WooCommerce/Shopify setup with payment gateway\n• Product upload (up to 50 products)\n• Shipping configuration\n• Tax settings',
    defaultRate: 0,
    defaultQuantity: 1,
  },
  {
    id: 'analytics-setup',
    title: 'Analytics & Tracking Setup',
    description: '• Google Analytics 4 + Search Console + Tag Manager\n• Conversion tracking setup\n• Custom dashboard creation\n• Monthly reporting template',
    defaultRate: 0,
    defaultQuantity: 1,
  },
  {
    id: 'training-session',
    title: 'Training Session',
    description: '• 1-hour website management training\n• Screen recording provided\n• Q&A session\n• Follow-up support for 1 week',
    defaultRate: 0,
    defaultQuantity: 1,
  },
  {
    id: 'rush-delivery',
    title: 'Rush Delivery Fee',
    description: '• Expedited delivery surcharge\n• Priority queue placement\n• Dedicated resource allocation',
    defaultRate: 0,
    defaultQuantity: 1,
  },
  {
    id: 'annual-maintenance',
    title: 'Annual Maintenance Contract',
    description: '• Yearly support renewal\n• Priority support response\n• Monthly health checks\n• Security updates included',
    defaultRate: 0,
    defaultQuantity: 1,
  },
];

export function productToInvoiceItem(product: Product): Omit<InvoiceItem, 'id'> {
  return {
    title: product.title,
    description: product.description,
    quantity: product.defaultQuantity || 1,
    rate: product.defaultRate || 0,
    discountType: 'percentage',
    discountValue: 0,
    discountAmount: 0,
    amount: 0,
  };
}
