import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Invoice } from '@/types/invoice';
import { 
  getAllInvoices, 
  createInvoice as createInvoiceApi, 
  updateInvoiceApi, 
  deleteInvoiceApi,
  getNextInvoiceNumber as getNextNumberApi
} from '@/services/invoiceService';

export function useInvoices() {
  const queryClient = useQueryClient();

  const invoicesQuery = useQuery({
    queryKey: ['invoices'],
    queryFn: async () => {
      const result = await getAllInvoices();
      if (result.error) {
        throw new Error(result.error);
      }
      // Map snake_case fields from API to camelCase for frontend
      return (result.data ?? []).map((invoice) => mapInvoiceFromApi(invoice as unknown as Record<string, unknown>));
    },
    staleTime: 5 * 60 * 1000,
  });

  const createMutation = useMutation({
    mutationFn: async (invoice: Invoice) => {
      // Map camelCase to snake_case for API
      const apiInvoice = mapInvoiceToApi(invoice);
      const result = await createInvoiceApi(apiInvoice as unknown as Invoice);
      if (result.error) throw new Error(result.error);
      return mapInvoiceFromApi(result.data as unknown as Record<string, unknown>);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['invoices'] });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<Invoice> }) => {
      const apiData = mapInvoiceToApi(data);
      const result = await updateInvoiceApi(id, apiData as unknown as Partial<Invoice>);
      if (result.error) throw new Error(result.error);
      return mapInvoiceFromApi(result.data as unknown as Record<string, unknown>);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['invoices'] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const result = await deleteInvoiceApi(id);
      if (result.error) throw new Error(result.error);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['invoices'] });
    },
  });

  const getInvoice = (id: string) => {
    return invoicesQuery.data?.find(inv => inv.id === id);
  };

  const getNextInvoiceNumber = async () => {
    const result = await getNextNumberApi();
    if (result.data) {
      return result.data.next_number;
    }
    // Fallback calculation
    const invoices = invoicesQuery.data ?? [];
    const maxNumber = invoices.reduce((max, inv) => {
      const num = parseInt(inv.invoiceNumber.replace(/\D/g, ''), 10);
      return isNaN(num) ? max : Math.max(max, num);
    }, 0);
    return `INV-${String(maxNumber + 1).padStart(4, '0')}`;
  };

  return {
    invoices: invoicesQuery.data ?? [],
    isLoading: invoicesQuery.isLoading,
    isError: invoicesQuery.isError,
    error: invoicesQuery.error,
    refetch: invoicesQuery.refetch,
    addInvoice: createMutation.mutateAsync,
    updateInvoice: updateMutation.mutateAsync,
    deleteInvoice: deleteMutation.mutateAsync,
    getInvoice,
    getNextInvoiceNumber,
  };
}

// Helper to map API response (snake_case) to frontend (camelCase)
function mapInvoiceFromApi(invoice: Record<string, unknown>): Invoice {
  return {
    id: invoice.id as string,
    invoiceNumber: (invoice.invoice_number || invoice.invoiceNumber) as string,
    date: invoice.date as string,
    dueDate: (invoice.due_date || invoice.dueDate) as string,
    client: invoice.client as Invoice['client'],
    company: invoice.company as Invoice['company'],
    items: invoice.items as Invoice['items'],
    currency: invoice.currency as Invoice['currency'],
    subtotal: Number(invoice.subtotal) || 0,
    taxRate: Number(invoice.tax_rate ?? invoice.taxRate) || 0,
    taxAmount: Number(invoice.tax_amount ?? invoice.taxAmount) || 0,
    discountType: (invoice.discount_type || invoice.discountType || 'percentage') as Invoice['discountType'],
    discountValue: Number(invoice.discount_value ?? invoice.discountValue) || 0,
    discountAmount: Number(invoice.discount_amount ?? invoice.discountAmount) || 0,
    total: Number(invoice.total) || 0,
    notes: invoice.notes as string | undefined,
    terms: invoice.terms as string | undefined,
    paymentInfo: (invoice.payment_info || invoice.paymentInfo) as Invoice['paymentInfo'],
    invoiceNotes: (invoice.invoice_notes || invoice.invoiceNotes) as Invoice['invoiceNotes'],
    signature: invoice.signature as Invoice['signature'],
    status: invoice.status as Invoice['status'],
    createdAt: (invoice.created_at || invoice.createdAt) as string,
  };
}

// Helper to map frontend (camelCase) to API (snake_case)
function mapInvoiceToApi(invoice: Partial<Invoice>): Record<string, unknown> {
  const mapped: Record<string, unknown> = {};
  
  if (invoice.id !== undefined) mapped.id = invoice.id;
  if (invoice.invoiceNumber !== undefined) mapped.invoice_number = invoice.invoiceNumber;
  if (invoice.date !== undefined) mapped.date = invoice.date;
  if (invoice.dueDate !== undefined) mapped.due_date = invoice.dueDate;
  if (invoice.client !== undefined) mapped.client = invoice.client;
  if (invoice.company !== undefined) mapped.company = invoice.company;
  if (invoice.items !== undefined) mapped.items = invoice.items;
  if (invoice.currency !== undefined) mapped.currency = invoice.currency;
  if (invoice.subtotal !== undefined) mapped.subtotal = invoice.subtotal;
  if (invoice.taxRate !== undefined) mapped.tax_rate = invoice.taxRate;
  if (invoice.taxAmount !== undefined) mapped.tax_amount = invoice.taxAmount;
  if (invoice.discountType !== undefined) mapped.discount_type = invoice.discountType;
  if (invoice.discountValue !== undefined) mapped.discount_value = invoice.discountValue;
  if (invoice.discountAmount !== undefined) mapped.discount_amount = invoice.discountAmount;
  if (invoice.total !== undefined) mapped.total = invoice.total;
  if (invoice.notes !== undefined) mapped.notes = invoice.notes;
  if (invoice.terms !== undefined) mapped.terms = invoice.terms;
  if (invoice.paymentInfo !== undefined) mapped.payment_info = invoice.paymentInfo;
  if (invoice.invoiceNotes !== undefined) mapped.invoice_notes = invoice.invoiceNotes;
  if (invoice.signature !== undefined) mapped.signature = invoice.signature;
  if (invoice.status !== undefined) mapped.status = invoice.status;
  if (invoice.createdAt !== undefined) mapped.created_at = invoice.createdAt;
  
  return mapped;
}
