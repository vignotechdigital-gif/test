import { useState, useEffect, useCallback } from 'react';
import {
  getAllTemplates,
  createTemplate as createTemplateApi,
  updateTemplateApi,
  deleteTemplateApi,
  getDefaultTemplate as getDefaultTemplateApi,
  Template,
  CreateTemplateData
} from '@/services/templateService';
import { isApiAvailable } from '@/services/api';

const STORAGE_KEY = 'templates';

export function useTemplates() {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [useApi, setUseApi] = useState(false);

  useEffect(() => {
    async function init() {
      setIsLoading(true);
      
      const apiAvailable = await isApiAvailable();
      setUseApi(apiAvailable);
      
      if (apiAvailable) {
        const result = await getAllTemplates();
        if (result.data) {
          setTemplates(result.data);
        } else {
          console.error('Failed to load templates from API:', result.error);
          loadFromLocalStorage();
        }
      } else {
        loadFromLocalStorage();
      }
      
      setIsLoading(false);
    }
    
    function loadFromLocalStorage() {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        try {
          setTemplates(JSON.parse(stored));
        } catch (e) {
          console.error('Failed to parse templates from storage');
        }
      }
    }
    
    init();
  }, []);

  const saveToLocalStorage = useCallback((newTemplates: Template[]) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newTemplates));
  }, []);

  const addTemplate = useCallback(async (template: CreateTemplateData) => {
    if (useApi) {
      const result = await createTemplateApi(template);
      if (result.data) {
        // If new template is default, update others
        if (template.is_default) {
          setTemplates(prev => [
            result.data!,
            ...prev.map(t => ({ ...t, is_default: false }))
          ]);
        } else {
          setTemplates(prev => [result.data!, ...prev]);
        }
        return result.data;
      } else {
        throw new Error(result.error);
      }
    } else {
      const newTemplate: Template = {
        ...template,
        id: Date.now(),
        is_default: template.is_default || false,
        created_at: new Date().toISOString(),
      };
      
      let newTemplates = [newTemplate, ...templates];
      if (template.is_default) {
        newTemplates = newTemplates.map(t => 
          t.id === newTemplate.id ? t : { ...t, is_default: false }
        );
      }
      
      setTemplates(newTemplates);
      saveToLocalStorage(newTemplates);
      return newTemplate;
    }
  }, [useApi, templates, saveToLocalStorage]);

  const updateTemplate = useCallback(async (id: number, updates: Partial<CreateTemplateData>) => {
    if (useApi) {
      const result = await updateTemplateApi(id, updates);
      if (result.data) {
        if (updates.is_default) {
          setTemplates(prev => prev.map(t => 
            t.id === id ? result.data! : { ...t, is_default: false }
          ));
        } else {
          setTemplates(prev => prev.map(t => t.id === id ? result.data! : t));
        }
        return result.data;
      } else {
        throw new Error(result.error);
      }
    } else {
      let newTemplates = templates.map(t =>
        t.id === id ? { ...t, ...updates } : t
      );
      
      if (updates.is_default) {
        newTemplates = newTemplates.map(t =>
          t.id === id ? t : { ...t, is_default: false }
        );
      }
      
      setTemplates(newTemplates);
      saveToLocalStorage(newTemplates);
    }
  }, [useApi, templates, saveToLocalStorage]);

  const deleteTemplate = useCallback(async (id: number) => {
    if (useApi) {
      const result = await deleteTemplateApi(id);
      if (!result.error) {
        setTemplates(prev => prev.filter(t => t.id !== id));
      } else {
        throw new Error(result.error);
      }
    } else {
      const newTemplates = templates.filter(t => t.id !== id);
      setTemplates(newTemplates);
      saveToLocalStorage(newTemplates);
    }
  }, [useApi, templates, saveToLocalStorage]);

  const getTemplate = useCallback((id: number) => {
    return templates.find(t => t.id === id);
  }, [templates]);

  const getDefaultTemplate = useCallback(async () => {
    if (useApi) {
      const result = await getDefaultTemplateApi();
      return result.data || null;
    }
    return templates.find(t => t.is_default) || templates[0] || null;
  }, [useApi, templates]);

  return {
    templates,
    isLoading,
    useApi,
    addTemplate,
    updateTemplate,
    deleteTemplate,
    getTemplate,
    getDefaultTemplate,
  };
}
