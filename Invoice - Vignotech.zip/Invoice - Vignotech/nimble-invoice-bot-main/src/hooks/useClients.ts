import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ClientInfo } from '@/types/invoice';
import {
  getAllClients,
  createClient as createClientApi,
  updateClientApi,
  deleteClientApi,
  Client
} from '@/services/clientService';

export function useClients() {
  const queryClient = useQueryClient();

  const clientsQuery = useQuery({
    queryKey: ['clients'],
    queryFn: async () => {
      const result = await getAllClients();
      return result.data ?? [];
    },
    staleTime: 5 * 60 * 1000,
  });

  const createMutation = useMutation({
    mutationFn: async (client: Omit<ClientInfo, 'id'>) => {
      const result = await createClientApi(client);
      if (result.error) throw new Error(result.error);
      return result.data!;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients'] });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<ClientInfo> }) => {
      const result = await updateClientApi(id, data);
      if (result.error) throw new Error(result.error);
      return result.data!;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients'] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const result = await deleteClientApi(id);
      if (result.error) throw new Error(result.error);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients'] });
    },
  });

  const getClient = (id: number) => {
    return clientsQuery.data?.find(c => c.id === id);
  };

  return {
    clients: clientsQuery.data ?? [],
    isLoading: clientsQuery.isLoading,
    isError: clientsQuery.isError,
    error: clientsQuery.error,
    refetch: clientsQuery.refetch,
    createClient: createMutation.mutateAsync,
    updateClient: updateMutation.mutateAsync,
    deleteClient: deleteMutation.mutateAsync,
    getClient,
  };
}

export type { Client };
