import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  getAllClientServices,
  getClientServicesByClientId,
  getUpcomingRenewals,
  createClientService,
  updateClientService,
  deleteClientService,
  ClientService,
} from '@/services/clientServiceService';

export function useClientServices(clientId?: number) {
  const queryClient = useQueryClient();

  const servicesQuery = useQuery({
    queryKey: clientId ? ['clientServices', clientId] : ['clientServices'],
    queryFn: () => clientId ? getClientServicesByClientId(clientId) : getAllClientServices(),
    staleTime: 5 * 60 * 1000,
  });

  const renewalsQuery = useQuery({
    queryKey: ['clientServices', 'renewals'],
    queryFn: () => getUpcomingRenewals(30),
    staleTime: 5 * 60 * 1000,
  });

  const createMutation = useMutation({
    mutationFn: (service: Omit<ClientService, 'id' | 'status' | 'created_at' | 'client_name' | 'client_company'>) =>
      createClientService(service),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clientServices'] });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<ClientService> }) =>
      updateClientService(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clientServices'] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => deleteClientService(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clientServices'] });
    },
  });

  return {
    services: Array.isArray(servicesQuery.data) ? servicesQuery.data : [],
    renewals: Array.isArray(renewalsQuery.data) ? renewalsQuery.data : [],
    isLoading: servicesQuery.isLoading,
    isError: servicesQuery.isError,
    error: servicesQuery.error,
    refetch: servicesQuery.refetch,
    createService: createMutation.mutateAsync,
    updateService: updateMutation.mutateAsync,
    deleteService: deleteMutation.mutateAsync,
    isCreating: createMutation.isPending,
    isUpdating: updateMutation.isPending,
    isDeleting: deleteMutation.isPending,
  };
}
