import { useState } from 'react';
import { Plus, Loader2, Pencil, Trash2, Search, Calendar, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { format, differenceInDays } from 'date-fns';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useClientServices } from '@/hooks/useClientServices';
import { useClients } from '@/hooks/useClients';
import { useInvoices } from '@/hooks/useInvoices';
import { ServiceFormDialog } from '@/components/services/ServiceFormDialog';
import { ClientService } from '@/services/clientServiceService';
import { toast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const STATUS_CONFIG = {
  active: { label: 'Active', color: 'bg-green-500/10 text-green-600 border-green-500/20', icon: CheckCircle },
  expiring_soon: { label: 'Expiring Soon', color: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20', icon: AlertTriangle },
  expired: { label: 'Expired', color: 'bg-red-500/10 text-red-600 border-red-500/20', icon: XCircle },
};

export default function ClientServices() {
  const { services, isLoading, isError, createService, updateService, deleteService, isCreating, isUpdating } = useClientServices();
  const { clients } = useClients();
  const { invoices } = useInvoices();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingService, setEditingService] = useState<ClientService | null>(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deletingService, setDeletingService] = useState<ClientService | null>(null);

  const serviceTypes = [...new Set(services.map(s => s.service_type))];

  const filteredServices = services.filter(service => {
    const matchesSearch = 
      service.service_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.service_type.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.client_name?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || service.status === statusFilter;
    const matchesType = typeFilter === 'all' || service.service_type === typeFilter;
    return matchesSearch && matchesStatus && matchesType;
  });

  const handleCreate = () => {
    setEditingService(null);
    setDialogOpen(true);
  };

  const handleEdit = (service: ClientService) => {
    setEditingService(service);
    setDialogOpen(true);
  };

  const handleDelete = (service: ClientService) => {
    setDeletingService(service);
    setDeleteConfirmOpen(true);
  };

  const confirmDelete = async () => {
    if (!deletingService) return;
    try {
      await deleteService(deletingService.id);
      toast({ title: 'Service deleted', description: 'The service has been removed.' });
    } catch (error) {
      toast({ 
        title: 'Error', 
        description: error instanceof Error ? error.message : 'Failed to delete service',
        variant: 'destructive' 
      });
    }
    setDeleteConfirmOpen(false);
    setDeletingService(null);
  };

  const handleSubmit = async (data: Record<string, unknown>) => {
    try {
      const formattedData = {
        ...data,
        start_date: data.start_date instanceof Date ? format(data.start_date, 'yyyy-MM-dd') : data.start_date,
        end_date: data.end_date instanceof Date ? format(data.end_date, 'yyyy-MM-dd') : data.end_date,
        invoice_id: data.invoice_id || null,
      };

      if (editingService) {
        await updateService({ id: editingService.id, data: formattedData as Partial<ClientService> });
        toast({ title: 'Service updated', description: 'The service has been updated.' });
      } else {
        await createService(formattedData as Omit<ClientService, 'id' | 'status' | 'created_at' | 'client_name' | 'client_company'>);
        toast({ title: 'Service created', description: 'The service has been added.' });
      }
      setDialogOpen(false);
    } catch (error) {
      toast({ 
        title: 'Error', 
        description: error instanceof Error ? error.message : 'Failed to save service',
        variant: 'destructive' 
      });
    }
  };

  const getDaysRemaining = (endDate: string) => {
    const days = differenceInDays(new Date(endDate), new Date());
    if (days < 0) return `${Math.abs(days)} days overdue`;
    if (days === 0) return 'Expires today';
    return `${days} days remaining`;
  };

  const formatCurrency = (amount: number, currency: string) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(amount);
  };

  // Count by status
  const statusCounts = {
    active: services.filter(s => s.status === 'active').length,
    expiring_soon: services.filter(s => s.status === 'expiring_soon').length,
    expired: services.filter(s => s.status === 'expired').length,
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Client Services</h1>
            <p className="text-muted-foreground">Track domains, hosting, and other subscriptions</p>
          </div>
          <Button onClick={handleCreate} variant="gradient">
            <Plus className="h-4 w-4" />
            Add Service
          </Button>
        </div>

        {/* Stats */}
        <div className="grid sm:grid-cols-3 gap-4 mb-8">
          <div className="rounded-xl border border-border bg-card p-5 shadow-card">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{statusCounts.active}</p>
                <p className="text-sm text-muted-foreground">Active</p>
              </div>
            </div>
          </div>
          <div className="rounded-xl border border-border bg-card p-5 shadow-card">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-yellow-500/10 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-yellow-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{statusCounts.expiring_soon}</p>
                <p className="text-sm text-muted-foreground">Expiring Soon</p>
              </div>
            </div>
          </div>
          <div className="rounded-xl border border-border bg-card p-5 shadow-card">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center">
                <XCircle className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{statusCounts.expired}</p>
                <p className="text-sm text-muted-foreground">Expired</p>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search services..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="expiring_soon">Expiring Soon</SelectItem>
              <SelectItem value="expired">Expired</SelectItem>
            </SelectContent>
          </Select>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {serviceTypes.map(type => (
                <SelectItem key={type} value={type}>{type}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : isError ? (
          <div className="text-center py-12">
            <p className="text-destructive">Failed to load services from database</p>
          </div>
        ) : filteredServices.length === 0 ? (
          <div className="text-center py-12">
            <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">
              {searchQuery || statusFilter !== 'all' || typeFilter !== 'all' 
                ? 'No services match your filters' 
                : 'No services found'}
            </p>
            {!searchQuery && statusFilter === 'all' && typeFilter === 'all' && (
              <Button onClick={handleCreate} variant="outline" className="mt-4">
                <Plus className="h-4 w-4 mr-2" />
                Add your first service
              </Button>
            )}
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredServices.map((service, index) => {
              const statusConfig = STATUS_CONFIG[service.status];
              const StatusIcon = statusConfig.icon;
              
              return (
                <div 
                  key={service.id} 
                  className="rounded-xl border border-border bg-card p-5 shadow-card hover:shadow-card-hover transition-shadow animate-fade-in flex flex-col"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <div className="flex items-start justify-between mb-3">
                    <Badge variant="outline" className={statusConfig.color}>
                      <StatusIcon className="w-3 h-3 mr-1" />
                      {statusConfig.label}
                    </Badge>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleEdit(service)}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => handleDelete(service)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-base font-semibold text-foreground truncate">{service.service_name}</h3>
                    <p className="text-sm font-medium text-primary mt-0.5">{service.service_type}</p>
                    <p className="text-sm text-muted-foreground mt-1 truncate">
                      {service.client_name}
                      {service.client_company && ` • ${service.client_company}`}
                    </p>
                    <div className="mt-3 pt-3 border-t border-border">
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(service.start_date), 'MMM d, yyyy')} - {format(new Date(service.end_date), 'MMM d, yyyy')}
                      </p>
                      <p className={`text-xs mt-1 ${service.status === 'expired' ? 'text-destructive' : 'text-muted-foreground'}`}>
                        {getDaysRemaining(service.end_date)}
                      </p>
                    </div>
                  </div>
                  <div className="mt-3 pt-3 border-t border-border flex items-center justify-between">
                    <p className="text-lg font-semibold text-foreground">
                      {formatCurrency(service.price, service.currency)}
                    </p>
                  </div>
                  {service.notes && (
                    <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{service.notes}</p>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </main>

      <ServiceFormDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        service={editingService}
        clients={clients}
        invoices={invoices}
        onSubmit={handleSubmit}
        isLoading={isCreating || isUpdating}
      />

      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Service</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {deletingService?.service_name}? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
