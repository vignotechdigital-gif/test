import { useState, useMemo } from 'react';
import { FileText, DollarSign, Clock, CheckCircle } from 'lucide-react';
import { Header } from '@/components/layout/Header';
import { StatsCard } from '@/components/invoice/StatsCard';
import { InvoiceCard } from '@/components/invoice/InvoiceCard';
import { EmptyState } from '@/components/invoice/EmptyState';
import { DashboardFilters, FilterState } from '@/components/invoice/DashboardFilters';
import { useInvoices } from '@/hooks/useInvoices';
import { toast } from '@/hooks/use-toast';
import { parseISO, isAfter, isBefore, startOfDay, endOfDay } from 'date-fns';

export default function Dashboard() {
  const { invoices, isLoading, deleteInvoice } = useInvoices();

  const [filters, setFilters] = useState<FilterState>({
    search: '',
    status: 'all',
    dateFrom: undefined,
    dateTo: undefined,
  });

  // Filter invoices based on current filters
  const filteredInvoices = useMemo(() => {
    return invoices.filter((invoice) => {
      // Search filter (invoice number or client name)
      if (filters.search) {
        const searchLower = filters.search.toLowerCase();
        const matchesNumber = invoice.invoiceNumber?.toLowerCase().includes(searchLower);
        const matchesClient = invoice.client?.name?.toLowerCase().includes(searchLower);
        const matchesEmail = invoice.client?.email?.toLowerCase().includes(searchLower);
        if (!matchesNumber && !matchesClient && !matchesEmail) {
          return false;
        }
      }

      // Status filter
      if (filters.status !== 'all' && invoice.status !== filters.status) {
        return false;
      }

      // Date range filter
      if (filters.dateFrom || filters.dateTo) {
        const invoiceDate = parseISO(invoice.date);
        
        if (filters.dateFrom && isBefore(invoiceDate, startOfDay(filters.dateFrom))) {
          return false;
        }
        
        if (filters.dateTo && isAfter(invoiceDate, endOfDay(filters.dateTo))) {
          return false;
        }
      }

      return true;
    });
  }, [invoices, filters]);

  const handleDelete = async (id: string) => {
    try {
      await deleteInvoice(id);
      toast({
        title: "Invoice Deleted",
        description: "The invoice has been removed.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete invoice",
        variant: "destructive",
      });
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  // Stats based on ALL invoices (not filtered)
  const totalRevenue = invoices.reduce((sum, inv) => sum + inv.total, 0);
  const paidInvoices = invoices.filter((inv) => inv.status === 'paid');
  const pendingInvoices = invoices.filter((inv) => inv.status === 'sent' || inv.status === 'draft');
  const pendingAmount = pendingInvoices.reduce((sum, inv) => sum + inv.total, 0);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container py-8">
          <div className="animate-pulse space-y-8">
            <div className="h-8 w-48 bg-muted rounded" />
            <div className="grid md:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-28 bg-muted rounded-xl" />
              ))}
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Dashboard</h1>
          <p className="text-muted-foreground">Manage your invoices and track payments</p>
        </div>

        {/* Stats */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatsCard
            title="Total Invoices"
            value={invoices.length}
            icon={FileText}
          />
          <StatsCard
            title="Total Revenue"
            value={formatCurrency(totalRevenue)}
            icon={DollarSign}
          />
          <StatsCard
            title="Pending"
            value={formatCurrency(pendingAmount)}
            icon={Clock}
          />
          <StatsCard
            title="Paid"
            value={paidInvoices.length}
            icon={CheckCircle}
          />
        </div>

        {/* Filters */}
        <DashboardFilters filters={filters} onFiltersChange={setFilters} />

        {/* Invoices List */}
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-xl font-semibold text-foreground">
            {filters.search || filters.status !== 'all' || filters.dateFrom || filters.dateTo
              ? `Filtered Invoices (${filteredInvoices.length})`
              : 'Recent Invoices'}
          </h2>
        </div>

        {invoices.length === 0 ? (
          <EmptyState />
        ) : filteredInvoices.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <p>No invoices match your filters.</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredInvoices.map((invoice) => (
              <InvoiceCard
                key={invoice.id}
                invoice={invoice}
                onDelete={handleDelete}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
