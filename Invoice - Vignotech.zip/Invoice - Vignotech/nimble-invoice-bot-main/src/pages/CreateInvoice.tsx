import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Plus, Save, Eye, ArrowLeft, Percent, DollarSign } from 'lucide-react';
import { format } from 'date-fns';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { InvoiceItemRow } from '@/components/invoice/InvoiceItemRow';
import { InvoicePreview } from '@/components/invoice/InvoicePreview';
import { LogoUpload } from '@/components/invoice/LogoUpload';
import { CurrencySelector } from '@/components/invoice/CurrencySelector';
import { ProductImportDialog } from '@/components/invoice/ProductImportDialog';
import { BillToSection } from '@/components/invoice/BillToSection';
import { PaymentInfoSection } from '@/components/invoice/PaymentInfoSection';
import { NotesSignatureSection } from '@/components/invoice/NotesSignatureSection';
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from '@/components/ui/resizable';
import { useInvoices } from '@/hooks/useInvoices';
import { Invoice, InvoiceItem, ClientInfo, CompanyInfo, DiscountType, CurrencyCode, PaymentInfo, InvoiceNotes, SignatureInfo } from '@/types/invoice';
// Products are now fetched from the database via ProductImportDialog
import { Link } from 'react-router-dom';
import vignotechLogo from '@/assets/vignotech-logo.png';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

function generateId() {
  return Math.random().toString(36).substring(2, 9);
}

const defaultCompany: CompanyInfo = {
  name: 'VignoTech Digital Solutions',
  email: 'vignotechdigital@gmail.com',
  address: '',
  city: 'Coimbatore',
  country: 'India',
  phone: '',
  logo: vignotechLogo,
};

const defaultClient: ClientInfo = {
  name: '',
  companyName: '',
  email: '',
  phone: '',
  addressLine1: '',
  addressLine2: '',
  city: '',
  stateProvince: '',
  postalCode: '',
  country: '',
  countryCode: '',
  taxId: '',
};

const defaultPaymentInfo: PaymentInfo = {
  paymentMethods: ['Bank Transfer'],
  bankDetails: {
    bankName: '',
    accountName: '',
    accountNumber: '',
    ifscCode: '',
    swiftCode: '',
    iban: '',
    branch: '',
  },
  paypalEmail: '',
  wiseEmail: '',
  upiId: '',
  paymentLink: '',
};

const defaultInvoiceNotes: InvoiceNotes = {
  internalNotes: '',
  clientNotes: '',
  thankYouMessage: 'We are grateful for your confidence in our services and look forward to serving you again.',
};

const defaultSignature: SignatureInfo = {
  authorizedSignatory: 'Harivignesh Jeeva',
  designation: 'Developer',
  digitalSignatureUrl: '',
};

const createEmptyItem = (): InvoiceItem => ({
  id: generateId(),
  title: '',
  description: '',
  quantity: 1,
  rate: 0,
  discountType: 'percentage',
  discountValue: 0,
  discountAmount: 0,
  amount: 0,
});

// Start with a single empty item - products can be imported from DB

export default function CreateInvoice() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const editId = searchParams.get('edit');
  const { addInvoice, updateInvoice, getInvoice, getNextInvoiceNumber } = useInvoices();
  const [showPreview, setShowPreview] = useState(false);

  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [dueDate, setDueDate] = useState(format(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd'));
  const [isEditMode, setIsEditMode] = useState(false);

  // Track if we've already loaded the invoice for editing (prevents re-fetching on every render)
  const [hasLoadedEditData, setHasLoadedEditData] = useState(false);

  // Load existing invoice if editing (only once)
  useEffect(() => {
    if (editId && !hasLoadedEditData) {
      const existingInvoice = getInvoice(editId);
      if (existingInvoice) {
        setIsEditMode(true);
        setInvoiceNumber(existingInvoice.invoiceNumber);
        setDate(existingInvoice.date);
        setDueDate(existingInvoice.dueDate);
        setCompany(existingInvoice.company);
        setClient(existingInvoice.client);
        // Normalize numeric values in items (API returns strings)
        const normalizedItems = existingInvoice.items.map(item => ({
          ...item,
          quantity: Number(item.quantity) || 1,
          rate: Number(item.rate) || 0,
          discountValue: Number(item.discountValue) || 0,
          discountAmount: Number(item.discountAmount) || 0,
          amount: Number(item.amount) || 0,
        }));
        setItems(normalizedItems);
        setCurrency(existingInvoice.currency);
        setTaxRate(Number(existingInvoice.taxRate) || 0);
        setDiscountType(existingInvoice.discountType);
        setDiscountValue(Number(existingInvoice.discountValue) || 0);
        setNotes(existingInvoice.notes || '');
        setTerms(existingInvoice.terms || '');
        setPaymentInfo(existingInvoice.paymentInfo || defaultPaymentInfo);
        setInvoiceNotes(existingInvoice.invoiceNotes || defaultInvoiceNotes);
        setSignature(existingInvoice.signature || defaultSignature);
        setHasLoadedEditData(true);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editId, getInvoice, hasLoadedEditData]);

  // Fetch next invoice number on mount (only for new invoices)
  useEffect(() => {
    if (!editId) {
      let cancelled = false;
      async function fetchInvoiceNumber() {
        const nextNumber = await getNextInvoiceNumber();
        if (!cancelled) {
          setInvoiceNumber(nextNumber);
        }
      }
      fetchInvoiceNumber();
      return () => { cancelled = true; };
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editId]);
  const [company, setCompany] = useState<CompanyInfo>(defaultCompany);
  const [client, setClient] = useState<ClientInfo>(defaultClient);
  const [items, setItems] = useState<InvoiceItem[]>([createEmptyItem()]);
  const [currency, setCurrency] = useState<CurrencyCode>('INR');
  const [taxRate, setTaxRate] = useState(0);
  const [discountType, setDiscountType] = useState<DiscountType>('percentage');
  const [discountValue, setDiscountValue] = useState(0);
  const [notes, setNotes] = useState(`Dear Teo,

Thank you for choosing VignoTech Digital Solutions for Teo's Bakery website!

📦 WHAT'S INCLUDED (3-YEAR PACKAGE):
• Domain (.com) - 3 years
• Premium Hosting - 3 years
• Custom Website Design & Development
• FREE: Production Support, SSL Certificate, Email Hosting, Backup Service, Content Writing, and Annual Maintenance (C$445 value!)

📄 WHAT WE NEED FROM YOU:
• Business logo (high resolution, PNG/SVG preferred)
• Photos of your bakery, products, and team
• Menu/product list with descriptions and prices
• Business hours and contact information
• Social media links (if any)
• Any specific colors, fonts, or design preferences
• About Us content (your story, vision, etc.)

⏰ TIMELINE:
• Website delivery: 10-14 business days after receiving all content
• Please provide content within 14 days to avoid delays

📧 SUPPORT:
• Email: vignotechdigital@gmail.com
• Hours: Mon-Fri, 10 AM - 6 PM IST
• Response time: Within 24 hours

🔄 RENEWAL (AFTER 3 YEARS):
• Domain renewal: ~C$25/year
• Hosting renewal: ~C$50/year
• Support/Maintenance: As per current rates
• Reminder will be sent 30 days before expiry

💳 PAYMENT:
• Total Amount: C$420.00
• Method: UPI - 7397236621@jupiteraxis
• Please share payment screenshot after transfer

We're excited to build your bakery's online presence!`);
  const [terms, setTerms] = useState(`TERMS & CONDITIONS:

1. Payment due upon receipt via PayPal/Wise/Bank Transfer.

2. Domain & hosting valid for 3 years. Renewal charges apply thereafter.

3. Website delivery: 10-14 business days from content receipt.

4. Includes 3 revision rounds. Additional changes billed separately.

5. Complimentary services (C$445 value) included free for 3 years.

6. Full ownership transfers upon complete payment.

7. Non-refundable once work commences.

8. Governed by the laws of India.

9. Payment constitutes acceptance of these terms. Payment is due within 30 days.`);
  const [paymentInfo, setPaymentInfo] = useState<PaymentInfo>(defaultPaymentInfo);
  const [invoiceNotes, setInvoiceNotes] = useState<InvoiceNotes>(defaultInvoiceNotes);
  const [signature, setSignature] = useState<SignatureInfo>(defaultSignature);

  // Calculate totals
  const subtotal = items.reduce((sum, item) => sum + item.amount, 0);
  const discountAmount = discountType === 'percentage' 
    ? (subtotal * discountValue) / 100 
    : Math.min(discountValue, subtotal);
  const taxableAmount = subtotal - discountAmount;
  const taxAmount = (taxableAmount * taxRate) / 100;
  const total = taxableAmount + taxAmount;

  const invoice: Partial<Invoice> = {
    invoiceNumber,
    date,
    dueDate,
    company,
    client,
    items,
    currency,
    subtotal,
    taxRate,
    taxAmount,
    discountType,
    discountValue,
    discountAmount,
    total,
    notes,
    terms,
    paymentInfo,
    invoiceNotes,
    signature,
  };

  const addItem = () => {
    setItems([...items, createEmptyItem()]);
  };

  const importProducts = (importedItems: Omit<InvoiceItem, 'id'>[]) => {
    const newItems: InvoiceItem[] = importedItems.map(item => ({
      id: generateId(),
      ...item,
    }));
    
    // If there's only one empty item, replace it; otherwise append
    if (items.length === 1 && !items[0].title && !items[0].description && items[0].rate === 0) {
      setItems(newItems);
    } else {
      setItems([...items, ...newItems]);
    }
    
    toast({
      title: "Products Imported",
      description: `${importedItems.length} product${importedItems.length !== 1 ? 's' : ''} added to invoice.`,
    });
  };

  const updateItem = (index: number, updatedItem: InvoiceItem) => {
    const newItems = [...items];
    newItems[index] = updatedItem;
    setItems(newItems);
  };

  const deleteItem = (index: number) => {
    if (items.length > 1) {
      setItems(items.filter((_, i) => i !== index));
    }
  };

  const handleSave = async (status: 'draft' | 'sent' = 'draft') => {
    if (!company.name || !client.name) {
      toast({
        title: "Missing Information",
        description: "Please fill in company and client names.",
        variant: "destructive",
      });
      return;
    }

    const invoiceData: Invoice = {
      id: isEditMode && editId ? editId : generateId(),
      invoiceNumber,
      date,
      dueDate,
      company,
      client,
      items,
      currency,
      subtotal,
      taxRate,
      taxAmount,
      discountType,
      discountValue,
      discountAmount,
      total,
      notes,
      terms,
      paymentInfo,
      invoiceNotes,
      signature,
      status,
      createdAt: isEditMode ? (getInvoice(editId!)?.createdAt || new Date().toISOString()) : new Date().toISOString(),
    };

    try {
      if (isEditMode && editId) {
        await updateInvoice({ id: editId, data: invoiceData });
        toast({
          title: "Invoice Updated",
          description: `Invoice ${invoiceNumber} has been updated.`,
        });
      } else {
        await addInvoice(invoiceData);
        toast({
          title: "Invoice Created",
          description: `Invoice ${invoiceNumber} has been saved.`,
        });
      }
      navigate('/');
    } catch (error) {
      toast({
        title: isEditMode ? "Failed to update invoice" : "Failed to create invoice",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="px-0 py-4">
        <div className="flex items-center gap-4 mb-4">
          <Button asChild variant="ghost" size="icon">
            <Link to="/">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-foreground">{isEditMode ? 'Edit Invoice' : 'Create Invoice'}</h1>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-sm text-muted-foreground">Invoice #:</span>
              <Input
                value={invoiceNumber}
                onChange={(e) => setInvoiceNumber(e.target.value)}
                className="h-7 w-32 text-sm font-medium"
                placeholder="INV-0001"
              />
            </div>
          </div>
        </div>

        {/* Mobile: stacked layout */}
        <div className="lg:hidden">
          <div
            id="create-invoice-form-column-mobile"
            className={`space-y-4 print:hidden ${showPreview ? 'hidden' : ''}`}
          >
            {/* Mobile form content rendered below */}
          </div>
          <div
            id="create-invoice-preview-column-mobile"
            className={`${!showPreview ? 'hidden' : ''}`}
          >
            <div className="flex items-center justify-between mb-4 print:hidden">
              <h2 className="text-lg font-semibold text-foreground">Preview</h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowPreview(false)}
              >
                <ArrowLeft className="h-4 w-4 mr-1" />
                Back to Form
              </Button>
            </div>
            <InvoicePreview invoice={invoice} />
          </div>
        </div>

        {/* Desktop: resizable panels */}
        <ResizablePanelGroup
          direction="horizontal"
          className="hidden lg:flex lg:h-[calc(100vh-120px)] print:block"
        >
          <ResizablePanel defaultSize={50} minSize={30} maxSize={70}>
            {/* Form - Independent Scroll */}
            <div
              id="create-invoice-form-column"
              className="space-y-4 h-full overflow-y-auto pr-2 print:hidden"
            >
            {/* Company Details */}
            <div className="rounded-lg border border-border bg-card p-4 shadow-card animate-fade-in">
              <h2 className="text-base font-semibold text-foreground mb-3">Your Company</h2>
              
              {/* Logo Upload */}
              <div className="mb-4">
                <Label className="mb-1.5 block text-sm">Company Logo</Label>
                <LogoUpload
                  logo={company.logo}
                  onLogoChange={(logo) => setCompany({ ...company, logo })}
                />
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <Label htmlFor="companyName">Company Name *</Label>
                  <Input
                    id="companyName"
                    value={company.name}
                    onChange={(e) => setCompany({ ...company, name: e.target.value })}
                    placeholder="Your Company Name"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="companyEmail">Email</Label>
                  <Input
                    id="companyEmail"
                    type="email"
                    value={company.email}
                    onChange={(e) => setCompany({ ...company, email: e.target.value })}
                    placeholder="company@example.com"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="companyPhone">Phone</Label>
                  <Input
                    id="companyPhone"
                    value={company.phone}
                    onChange={(e) => setCompany({ ...company, phone: e.target.value })}
                    placeholder="+1 234 567 890"
                    className="mt-1"
                  />
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="companyAddress">Address</Label>
                  <Input
                    id="companyAddress"
                    value={company.address}
                    onChange={(e) => setCompany({ ...company, address: e.target.value })}
                    placeholder="123 Business Street"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="companyCity">City</Label>
                  <Input
                    id="companyCity"
                    value={company.city}
                    onChange={(e) => setCompany({ ...company, city: e.target.value })}
                    placeholder="New York"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="companyCountry">Country</Label>
                  <Input
                    id="companyCountry"
                    value={company.country}
                    onChange={(e) => setCompany({ ...company, country: e.target.value })}
                    placeholder="United States"
                    className="mt-1"
                  />
                </div>
              </div>
            </div>

            {/* Client Details - Enhanced Bill To Section */}
            <BillToSection client={client} onChange={setClient} />

            {/* Invoice Details */}
            <div className="rounded-lg border border-border bg-card p-4 shadow-card animate-fade-in">
              <h2 className="text-base font-semibold text-foreground mb-3">Invoice Details</h2>
              <div className="grid sm:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="date">Issue Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="dueDate">Due Date</Label>
                  <Input
                    id="dueDate"
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label>Currency</Label>
                  <div className="mt-1">
                    <CurrencySelector
                      value={currency}
                      onChange={setCurrency}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Line Items */}
            <div className="rounded-lg border border-border bg-card p-4 shadow-card animate-fade-in">
              <h2 className="text-base font-semibold text-foreground mb-3">Line Items</h2>
              
              <div className="overflow-x-auto border border-border rounded-lg">
                <table className="min-w-[1100px] w-full border-collapse">
                  <thead>
                    <tr className="bg-muted/50">
                      <th className="border border-border p-3 text-center text-xs font-semibold text-muted-foreground uppercase tracking-wider w-12">#</th>
                      <th className="border border-border p-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider min-w-[380px]">Item Details</th>
                      <th className="border border-border p-3 text-center text-xs font-semibold text-muted-foreground uppercase tracking-wider w-20">Qty</th>
                      <th className="border border-border p-3 text-center text-xs font-semibold text-muted-foreground uppercase tracking-wider w-32">Rate ($)</th>
                      <th className="border border-border p-3 text-center text-xs font-semibold text-muted-foreground uppercase tracking-wider w-40">Discount</th>
                      <th className="border border-border p-3 text-center text-xs font-semibold text-muted-foreground uppercase tracking-wider w-32">Amount</th>
                      <th className="border border-border p-3 text-center text-xs font-semibold text-muted-foreground uppercase tracking-wider w-14"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((item, index) => (
                      <InvoiceItemRow
                        key={item.id}
                        item={item}
                        index={index}
                        onChange={(updatedItem) => updateItem(index, updatedItem)}
                        onDelete={() => deleteItem(index)}
                        canDelete={items.length > 1}
                      />
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex gap-3 mt-4">
                <Button type="button" variant="outline" onClick={addItem} className="flex-1">
                  <Plus className="h-4 w-4" />
                  Add Item
                </Button>
                <ProductImportDialog onImport={importProducts} />
              </div>
            </div>

            {/* Tax & Discount */}
            <div className="rounded-lg border border-border bg-card p-4 shadow-card animate-fade-in">
              <h2 className="text-base font-semibold text-foreground mb-3">Tax & Discount</h2>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <Label>Invoice Discount</Label>
                  <div className="flex gap-2 mt-1">
                    <div className="flex rounded-lg border border-input overflow-hidden">
                      <button
                        type="button"
                        onClick={() => setDiscountType('percentage')}
                        className={cn(
                          "px-3 py-2 text-sm transition-colors",
                          discountType === 'percentage' 
                            ? "bg-primary text-primary-foreground" 
                            : "bg-background text-muted-foreground hover:bg-muted"
                        )}
                      >
                        <Percent className="h-4 w-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setDiscountType('fixed')}
                        className={cn(
                          "px-3 py-2 text-sm transition-colors",
                          discountType === 'fixed' 
                            ? "bg-primary text-primary-foreground" 
                            : "bg-background text-muted-foreground hover:bg-muted"
                        )}
                      >
                        <DollarSign className="h-4 w-4" />
                      </button>
                    </div>
                    <Input
                      type="number"
                      min="0"
                      max={discountType === 'percentage' ? '100' : undefined}
                      step={discountType === 'percentage' ? '1' : '0.01'}
                      value={discountValue}
                      onChange={(e) => setDiscountValue(parseFloat(e.target.value) || 0)}
                      placeholder={discountType === 'percentage' ? '0%' : '$0.00'}
                      className="flex-1"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {discountType === 'percentage' ? 'Percentage off subtotal' : 'Fixed amount off subtotal'}
                  </p>
                </div>
                <div>
                  <Label htmlFor="tax">Tax Rate (%)</Label>
                  <Input
                    id="tax"
                    type="number"
                    min="0"
                    max="100"
                    value={taxRate}
                    onChange={(e) => setTaxRate(parseFloat(e.target.value) || 0)}
                    className="mt-1"
                  />
                </div>
              </div>
            </div>

            {/* Payment Information */}
            <PaymentInfoSection
              paymentInfo={paymentInfo}
              onChange={setPaymentInfo}
            />

            {/* Notes, Terms & Signature */}
            <NotesSignatureSection
              notes={notes}
              terms={terms}
              invoiceNotes={invoiceNotes}
              signature={signature}
              onNotesChange={setNotes}
              onTermsChange={setTerms}
              onInvoiceNotesChange={setInvoiceNotes}
              onSignatureChange={setSignature}
            />

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Button onClick={() => handleSave('draft')} variant="outline" className="flex-1">
                <Save className="h-4 w-4" />
                Save as Draft
              </Button>
              <Button onClick={() => handleSave('sent')} variant="gradient" className="flex-1">
                {isEditMode ? 'Update Invoice' : 'Create Invoice'}
              </Button>
            </div>
            </div>
          </ResizablePanel>

          <ResizableHandle withHandle className="bg-border hover:bg-primary/50 transition-colors" />

          <ResizablePanel defaultSize={50} minSize={30} maxSize={70}>
            {/* Preview - Independent Scroll */}
            <div
              id="create-invoice-preview-column"
              className="h-full overflow-y-auto pl-2"
            >
              <div className="flex items-center justify-between mb-4 print:hidden">
                <h2 className="text-lg font-semibold text-foreground">Preview</h2>
              </div>
              <InvoicePreview invoice={invoice} />
            </div>
          </ResizablePanel>
        </ResizablePanelGroup>

        {/* Mobile Preview Toggle */}
        <div className="fixed bottom-6 right-6 lg:hidden">
          <Button
            onClick={() => setShowPreview(!showPreview)}
            variant="gradient"
            size="lg"
            className="rounded-full shadow-lg"
          >
            <Eye className="h-5 w-5" />
            {showPreview ? 'Edit' : 'Preview'}
          </Button>
        </div>
      </main>
    </div>
  );
}
