import { useEffect, useRef } from 'react';
import { useParams, useSearchParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Download, Printer, Edit2 } from 'lucide-react';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { InvoicePreview } from '@/components/invoice/InvoicePreview';
import { useInvoices } from '@/hooks/useInvoices';
import { toast } from '@/hooks/use-toast';

export default function ViewInvoice() {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { getInvoice, updateInvoice } = useInvoices();
  const previewRef = useRef<HTMLDivElement>(null);

  const invoice = id ? getInvoice(id) : undefined;
  const shouldDownload = searchParams.get('download') === 'true';

  useEffect(() => {
    if (shouldDownload && invoice) {
      handlePrint();
    }
  }, [shouldDownload, invoice]);

  const handlePrint = () => {
    window.print();
  };

  const markAsPaid = async () => {
    if (invoice && id) {
      try {
        await updateInvoice({ id, data: { status: 'paid' } });
        toast({
          title: "Invoice Updated",
          description: "Invoice has been marked as paid.",
        });
        navigate(0); // Refresh to show updated status
      } catch (error) {
        toast({
          title: "Error",
          description: error instanceof Error ? error.message : "Failed to update invoice",
          variant: "destructive",
        });
      }
    }
  };

  if (!invoice) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container py-8">
          <div className="text-center py-16">
            <h2 className="text-xl font-semibold text-foreground mb-2">Invoice not found</h2>
            <p className="text-muted-foreground mb-6">The invoice you're looking for doesn't exist.</p>
            <Button asChild>
              <Link to="/">Back to Dashboard</Link>
            </Button>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="no-print">
        <Header />
      </div>
      
      <main className="container py-8 max-w-4xl">
        <div className="flex items-center justify-between mb-8 no-print">
          <div className="flex items-center gap-4">
            <Button asChild variant="ghost" size="icon">
              <Link to="/">
                <ArrowLeft className="h-5 w-5" />
              </Link>
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-foreground">{invoice.invoiceNumber}</h1>
              <p className="text-sm text-muted-foreground">{invoice.client.name}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {invoice.status !== 'paid' && (
              <Button variant="success" onClick={markAsPaid}>
                Mark as Paid
              </Button>
            )}
            <Button variant="outline" onClick={handlePrint}>
              <Printer className="h-4 w-4" />
              Print
            </Button>
            <Button variant="gradient" onClick={handlePrint}>
              <Download className="h-4 w-4" />
              Download PDF
            </Button>
          </div>
        </div>

        <InvoicePreview ref={previewRef} invoice={invoice} />
      </main>
    </div>
  );
}
