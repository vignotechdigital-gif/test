import { useState } from 'react';
import { Users, Plus, Loader2, Pencil, Trash2, Search, Briefcase, Eye, Mail, Phone, MapPin, Building, Hash, Globe, FileText } from 'lucide-react';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useClients } from '@/hooks/useClients';
import { ClientFormDialog } from '@/components/clients/ClientFormDialog';
import { Client } from '@/services/clientService';
import { toast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

export default function Clients() {
  const { clients, isLoading, isError, createClient, updateClient, deleteClient } = useClients();
  const [searchQuery, setSearchQuery] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deletingClient, setDeletingClient] = useState<Client | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [viewingClient, setViewingClient] = useState<Client | null>(null);

  const filteredClients = clients.filter(client => 
    client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    client.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (client.companyName?.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleCreate = () => {
    setEditingClient(null);
    setDialogOpen(true);
  };

  const handleEdit = (client: Client) => {
    setEditingClient(client);
    setDialogOpen(true);
  };

  const handleDelete = (client: Client) => {
    setDeletingClient(client);
    setDeleteConfirmOpen(true);
  };

  const confirmDelete = async () => {
    if (!deletingClient) return;
    try {
      await deleteClient(deletingClient.id);
      toast({ title: 'Client deleted', description: `${deletingClient.name} has been removed.` });
    } catch (error) {
      toast({ 
        title: 'Error', 
        description: error instanceof Error ? error.message : 'Failed to delete client',
        variant: 'destructive' 
      });
    }
    setDeleteConfirmOpen(false);
    setDeletingClient(null);
  };

  const handleSubmit = async (data: Record<string, unknown>) => {
    setIsSubmitting(true);
    try {
      if (editingClient) {
        await updateClient({ id: editingClient.id, data: data as Partial<import('@/types/invoice').ClientInfo> });
        toast({ title: 'Client updated', description: `${data.name} has been updated.` });
      } else {
        await createClient(data as Omit<import('@/types/invoice').ClientInfo, 'id'>);
        toast({ title: 'Client created', description: `${data.name} has been added.` });
      }
      setDialogOpen(false);
    } catch (error) {
      toast({ 
        title: 'Error', 
        description: error instanceof Error ? error.message : 'Failed to save client',
        variant: 'destructive' 
      });
    }
    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Clients</h1>
            <p className="text-muted-foreground">Manage your client database</p>
          </div>
          <Button onClick={handleCreate} variant="gradient">
            <Plus className="h-4 w-4" />
            Add Client
          </Button>
        </div>

        {/* Search */}
        <div className="mb-6 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search clients by name, email, or company..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 max-w-md"
          />
        </div>

        {/* Stats */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          <div className="rounded-xl border border-border bg-card p-5 shadow-card">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Users className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{clients.length}</p>
                <p className="text-sm text-muted-foreground">Total Clients</p>
              </div>
            </div>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : isError ? (
          <div className="text-center py-12">
            <p className="text-destructive">Failed to load clients from database</p>
          </div>
        ) : filteredClients.length === 0 ? (
          <div className="text-center py-12">
            <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">
              {searchQuery ? 'No clients match your search' : 'No clients found'}
            </p>
            {!searchQuery && (
              <Button onClick={handleCreate} variant="outline" className="mt-4">
                <Plus className="h-4 w-4 mr-2" />
                Add your first client
              </Button>
            )}
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredClients.map((client, index) => (
              <div 
                key={client.id} 
                className="rounded-xl border border-border bg-card p-5 shadow-card hover:shadow-card-hover transition-shadow animate-fade-in flex flex-col"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <span className="text-base font-semibold text-primary">
                      {client.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setViewingClient(client)}
                      title="View details"
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => handleEdit(client)}
                      title="Edit client"
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-destructive hover:text-destructive"
                      onClick={() => handleDelete(client)}
                      title="Delete client"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-base font-semibold text-foreground truncate">{client.name}</h3>
                  {client.companyName && (
                    <div className="flex items-center gap-1 text-sm text-muted-foreground mt-0.5">
                      <Briefcase className="w-3 h-3 shrink-0" />
                      <span className="truncate">{client.companyName}</span>
                    </div>
                  )}
                  <p className="text-sm text-muted-foreground mt-2 truncate">{client.email}</p>
                  {client.phone && (
                    <p className="text-sm text-muted-foreground truncate">{client.phone}</p>
                  )}
                  <p className="text-xs text-muted-foreground mt-2">
                    {client.city}, {client.country}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      <ClientFormDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        client={editingClient}
        onSubmit={handleSubmit}
        isLoading={isSubmitting}
      />

      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Client</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {deletingClient?.name}? This action cannot be undone.
              {deletingClient && (
                <span className="block mt-2 text-destructive">
                  Note: Clients with existing invoices cannot be deleted.
                </span>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* View Client Dialog */}
      <Dialog open={!!viewingClient} onOpenChange={(open) => !open && setViewingClient(null)}>
        <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-lg font-semibold text-primary">
                  {viewingClient?.name.charAt(0).toUpperCase()}
                </span>
              </div>
              Client Details
            </DialogTitle>
          </DialogHeader>
          
          {viewingClient && (
            <div className="space-y-3 mt-2">
              {/* Basic Info */}
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2">
                  <p className="text-xs text-muted-foreground">Full Name</p>
                  <p className="text-sm font-medium">{viewingClient.name}</p>
                </div>
                
                <div className="col-span-2">
                  <p className="text-xs text-muted-foreground">Company Name</p>
                  <p className="text-sm font-medium">{viewingClient.companyName || <span className="text-muted-foreground italic">Not set</span>}</p>
                </div>
              </div>

              <div className="border-t pt-3">
                <p className="text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wide">Contact</p>
                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2">
                    <p className="text-xs text-muted-foreground">Email</p>
                    <p className="text-sm font-medium">{viewingClient.email}</p>
                  </div>
                  
                  <div className="col-span-2">
                    <p className="text-xs text-muted-foreground">Phone</p>
                    <p className="text-sm font-medium">{viewingClient.phone || <span className="text-muted-foreground italic">Not set</span>}</p>
                  </div>
                </div>
              </div>

              <div className="border-t pt-3">
                <p className="text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wide">Address</p>
                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2">
                    <p className="text-xs text-muted-foreground">Address Line 1</p>
                    <p className="text-sm font-medium">{viewingClient.addressLine1}</p>
                  </div>
                  
                  <div className="col-span-2">
                    <p className="text-xs text-muted-foreground">Address Line 2</p>
                    <p className="text-sm font-medium">{viewingClient.addressLine2 || <span className="text-muted-foreground italic">Not set</span>}</p>
                  </div>
                  
                  <div>
                    <p className="text-xs text-muted-foreground">City</p>
                    <p className="text-sm font-medium">{viewingClient.city}</p>
                  </div>
                  
                  <div>
                    <p className="text-xs text-muted-foreground">State/Province</p>
                    <p className="text-sm font-medium">{viewingClient.stateProvince || <span className="text-muted-foreground italic">Not set</span>}</p>
                  </div>
                  
                  <div>
                    <p className="text-xs text-muted-foreground">Postal Code</p>
                    <p className="text-sm font-medium">{viewingClient.postalCode || <span className="text-muted-foreground italic">Not set</span>}</p>
                  </div>
                  
                  <div>
                    <p className="text-xs text-muted-foreground">Country</p>
                    <p className="text-sm font-medium">{viewingClient.country}</p>
                  </div>
                  
                  <div>
                    <p className="text-xs text-muted-foreground">Country Code</p>
                    <p className="text-sm font-medium">{viewingClient.countryCode || <span className="text-muted-foreground italic">Not set</span>}</p>
                  </div>
                </div>
              </div>

              <div className="border-t pt-3">
                <p className="text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wide">Tax & System</p>
                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2">
                    <p className="text-xs text-muted-foreground">Tax ID (VAT/GST)</p>
                    <p className="text-sm font-medium">{viewingClient.taxId || <span className="text-muted-foreground italic">Not set</span>}</p>
                  </div>
                  
                  <div>
                    <p className="text-xs text-muted-foreground">Client ID</p>
                    <p className="text-sm font-medium">#{viewingClient.id}</p>
                  </div>
                  
                  <div>
                    <p className="text-xs text-muted-foreground">Created At</p>
                    <p className="text-sm font-medium">
                      {viewingClient.created_at 
                        ? new Date(viewingClient.created_at).toLocaleDateString() 
                        : <span className="text-muted-foreground italic">Unknown</span>}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end gap-2 pt-4 border-t">
                <Button
                  variant="outline"
                  onClick={() => {
                    setViewingClient(null);
                    handleEdit(viewingClient);
                  }}
                >
                  <Pencil className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
