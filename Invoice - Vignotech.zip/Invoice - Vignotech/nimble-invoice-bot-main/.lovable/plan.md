# Full CRUD Operations & Client Services Implementation Plan

## Overview

This plan adds complete management capabilities for Products, Invoices, and Clients, with a new Client Services feature to track subscriptions (domain, hosting, etc.) with renewal dates.

---

## 1. Products Tab - Full CRUD Operations

### Current State

- Products page displays list from database
- Service layer (`productService.ts`) already has create/update/delete functions
- Hook (`useProducts.ts`) already exposes mutations
- Missing: UI for add/edit/delete operations

### Changes Required

**Update `src/pages/Products.tsx`:**

- Replace "New Invoice" button with "Add Product" button
- Add Edit and Delete buttons to each product card
- Create a Product Form Dialog for add/edit operations
- Add confirmation dialog before delete
- Show default rate and quantity in product cards

**New Component: `src/components/products/ProductFormDialog.tsx`**

- Form fields: ID (auto-generated for new), Title, Description, Default Rate, Default Quantity
- Validation using react-hook-form + zod
- Handles both create and edit modes

---

## 2. Invoices Tab - Database Integration with CRUD

### Current State

- `useInvoices` hook uses localStorage with API fallback
- Dashboard shows invoices from localStorage
- Invoice service layer is ready for API calls

### Changes Required

**Update `src/hooks/useInvoices.ts`:**

- Remove localStorage fallback since API is now primary
- Convert to use react-query for consistency with products
- Add proper field mapping between frontend (camelCase) and API (snake_case)

**Update `src/pages/Index.tsx` (Dashboard):**

- Rename "Dashboard" to "Invoices" for clarity
- Add Edit and Delete buttons to invoice cards
- Edit navigates to `/create?edit=<id>`
- Add confirmation dialog for delete

**Update `src/pages/CreateInvoice.tsx`:**

- Support edit mode via URL query parameter
- Load existing invoice data when editing
- Update button text to "Update Invoice" when editing

**Update `src/components/invoice/InvoiceCard.tsx`:**

- Add Edit and Delete action buttons
- Add status change dropdown (draft/sent/paid/overdue)

---

## 3. Dashboard Stats - Fetch from Database

### Current State

- Stats calculated client-side from loaded invoices
- Already works correctly since invoices are fetched from DB

### Verification

- Once invoices fetch from MariaDB, stats will automatically use database data
- No additional changes needed - the current calculation logic is correct

---

## 4. Clients Page - New Management Section

### Current State

- Clients table exists in schema
- `clientService.ts` and `useClients.ts` hook exist
- API endpoint `clients.php` is ready
- No dedicated Clients page in the UI

### Changes Required

**New Page: `src/pages/Clients.tsx`**

- List all clients from database
- Add/Edit/Delete operations with dialog forms
- Search and filter functionality
- Show client count and quick stats

**New Component: `src/components/clients/ClientFormDialog.tsx`**

- All client fields: name, company, email, phone, address lines, city, state, postal code, country, tax ID
- Form validation

**Update `src/App.tsx`:**

- Add route `/clients` for Clients page

**Update `src/components/layout/Header.tsx`:**

- Add "Clients" tab in navigation

---

## 5. Client Services Table - Subscription Tracking

### Database Schema

**New Table: `client_services`**

```sql
CREATE TABLE IF NOT EXISTS client_services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT NOT NULL,
    service_type VARCHAR(100) NOT NULL,
    service_name VARCHAR(255) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    price DECIMAL(15, 2) DEFAULT 0,
    currency VARCHAR(10) DEFAULT 'USD',
    status ENUM('active', 'expiring_soon', 'expired') DEFAULT 'active',
    invoice_id VARCHAR(50),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE SET NULL,
    INDEX idx_client (client_id),
    INDEX idx_status (status),
    INDEX idx_end_date (end_date)
);
```

### New PHP API: `api/client_services.php`

- GET all services (with optional client_id filter)
- GET single service
- POST create service
- PUT update service
- DELETE service
- GET upcoming renewals (services expiring within 30 days)

### New Service Layer: `src/services/clientServiceService.ts`

- CRUD operations for client services

### New Hook: `src/hooks/useClientServices.ts`

- React Query based hook for services management

### UI Updates

**Update `src/pages/Clients.tsx`:**

- Add "Services" tab or expandable section per client
- Show service count badge on each client card

**New Page: `src/pages/ClientServices.tsx`**

- List all services across all clients
- Filter by client, status, service type
- Sort by expiry date (upcoming renewals first)
- Color-coded status badges (green=active, yellow=expiring soon, red=expired)

**New Component: `src/components/services/ServiceFormDialog.tsx`**

- Client dropdown (select from existing clients)
- Service type dropdown: Domain, Hosting, SSL, Email, CDN, Maintenance, etc.
- Service name (e.g., "example.com", "Premium Hosting Plan")
- Start and end dates with date pickers
- Price and currency
- Optional invoice link (dropdown of invoices for selected client)
- Notes field

---

## Technical Details

### File Structure After Implementation

```text
src/
├── pages/
│   ├── Index.tsx (Invoices Dashboard)
│   ├── Products.tsx (with CRUD)
│   ├── Clients.tsx (NEW)
│   └── ClientServices.tsx (NEW)
├── components/
│   ├── products/
│   │   └── ProductFormDialog.tsx (NEW)
│   ├── clients/
│   │   └── ClientFormDialog.tsx (NEW)
│   └── services/
│       └── ServiceFormDialog.tsx (NEW)
├── services/
│   └── clientServiceService.ts (NEW)
└── hooks/
    └── useClientServices.ts (NEW)

api/
├── client_services.php (NEW)
└── client_services_schema.sql (NEW)
```

### Navigation Structure

```text
Header Navigation:
[Invoices] [Products] [Clients] [Services]
```

### Data Relationships

```text
clients (1) ──── (many) client_services
    │                       │
    │                       └── (optional) links to invoice
    │
    └── (many) invoices (via client_id)
```

---

## Implementation Order

1. **Products CRUD UI** - Add form dialog and action buttons
2. **Invoices from DB** - Update hook to use react-query, add edit/delete to cards
3. **Clients Page** - Create page with full CRUD
4. **Client Services Schema** - Add table and PHP API
5. **Client Services UI** - Create page and form components
6. **Navigation Update** - Add all tabs to header

https://bcrypt-generator.com/
INSERT INTO users (id, email, name, password_hash) VALUES (
'user_002',
'your@email.com',
'Your Name',
'PASTE_THE_HASH_HERE'
);

Test update
